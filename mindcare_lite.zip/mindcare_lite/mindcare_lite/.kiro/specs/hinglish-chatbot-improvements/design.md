# Design Document: Hinglish Chatbot Improvements

## Overview

This design document specifies the technical implementation for enhancing the CalmNest chatbot with Hinglish language support and an improved, more spacious user interface. The implementation will add language detection capabilities to identify when users communicate in Hinglish (Hindi-English mix written in Roman script), generate appropriate responses in the detected language, and expand the chat interface layout for better readability.

### Key Design Goals

1. **Language Detection**: Implement a lightweight, rule-based Hinglish detector that analyzes user input for Hindi words written in Roman script
2. **Bilingual Response Generation**: Extend the existing response system to generate contextually appropriate responses in both English and Hinglish
3. **Language Consistency**: Maintain per-message language detection to allow natural language switching within conversations
4. **Improved Layout**: Expand the chat interface dimensions while maintaining responsive design and visual aesthetics
5. **Backward Compatibility**: Preserve all existing safety features, crisis detection, and functionality

### Design Approach

The design follows a minimally invasive approach that extends existing components rather than replacing them. The language detection will be implemented as a new module that integrates into the request processing pipeline before response generation. The response generator will be enhanced with bilingual templates and AI prompt modifications. The UI changes will be CSS-based adjustments to container dimensions and spacing.

## Architecture

### System Components

The enhanced system consists of the following components:

```
┌─────────────────────────────────────────────────────────────┐
│                     Chat Interface (HTML/CSS/JS)             │
│  - Expanded layout (max-w-5xl, h-[500px])                   │
│  - Improved spacing and readability                          │
│  - Bilingual quick action buttons                            │
└────────────────────┬────────────────────────────────────────┘
                     │ HTTP POST /chat-stream
                     ▼
┌─────────────────────────────────────────────────────────────┐
│                   Flask Backend (app.py)                     │
│                                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  chat_stream() endpoint                               │   │
│  │  - Receives user message                              │   │
│  │  - Calls language detector                            │   │
│  │  - Passes language context to response generator      │   │
│  └────────────┬─────────────────────────────────────────┘   │
│               │                                               │
│               ▼                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  detect_language(message: str) -> str                 │   │
│  │  - Analyzes message for Hinglish indicators          │   │
│  │  - Returns "hinglish" or "english"                    │   │
│  └────────────┬─────────────────────────────────────────┘   │
│               │                                               │
│               ▼                                               │
│  ┌──────────────────────────────────────────────────────┐   │
│  │  Response Generation (Ollama/AI)                      │   │
│  │  - Receives language preference                       │   │
│  │  - Generates response in appropriate language         │   │
│  │  - Maintains safety checks regardless of language     │   │
│  └──────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────┘
```

### Component Interactions

1. **User Input Flow**: User types message → Frontend captures input → POST to /chat-stream endpoint
2. **Language Detection Flow**: Backend receives message → detect_language() analyzes text → Returns language classification
3. **Response Generation Flow**: Language preference + message → AI prompt construction (with language instruction) → Streaming response generation
4. **UI Rendering Flow**: Streamed response chunks → Frontend displays incrementally → Message saved to localStorage

### Integration Points

- **Language Detector Integration**: Called at the beginning of `chat_stream()` function before building the AI prompt
- **AI Prompt Modification**: Language preference injected into the system prompt context for Ollama/AI models
- **Rule-based Response Extension**: Bilingual response dictionaries added to `get_bot_response()` for fallback scenarios
- **UI Layout Changes**: CSS class modifications in `templates/chatbot/chat.html`

## Components and Interfaces

### 1. Language Detection Module

**Location**: `app.py` (new function)

**Function Signature**:
```python
def detect_language(message: str) -> str:
    """
    Detects if a message is in Hinglish or English.
    
    Args:
        message: User input text
        
    Returns:
        "hinglish" if message contains >= 20% Hinglish words
        "english" otherwise
    """
```

**Implementation Strategy**:

The language detector uses a rule-based approach with a curated list of common Hinglish words written in Roman script. This approach is chosen over ML-based detection for several reasons:
- Lightweight and fast (no model loading overhead)
- Deterministic and debuggable
- Sufficient accuracy for the common Hinglish patterns used in informal chat
- No external dependencies

**Hinglish Indicator Words** (examples):
- Common verbs: "kar", "karo", "kiya", "hai", "hoon", "ho", "tha", "thi", "raha", "rahi"
- Question words: "kya", "kaise", "kab", "kahan", "kyun", "kaun"
- Pronouns: "mai", "main", "mujhe", "mera", "tera", "aap", "tum", "hum"
- Common words: "nahi", "nahin", "haan", "acha", "thik", "bahut", "zyada", "kam"
- Mental health context: "pareshan", "tension", "dukh", "khushi", "dar", "chinta"

**Detection Algorithm**:
1. Tokenize message into words (split by whitespace and punctuation)
2. Count total words
3. Count words that match Hinglish indicator list (case-insensitive)
4. Calculate percentage: (hinglish_words / total_words) * 100
5. Return "hinglish" if percentage >= 20%, else "english"

**Edge Cases**:
- Empty messages: Return "english" (default)
- Very short messages (1-2 words): May misclassify, but acceptable given context
- Mixed language with English dominance: Correctly returns "english"
- All-caps input: Handled by case-insensitive matching

### 2. Enhanced Response Generator

**Modified Functions**:
- `chat_stream()`: Add language detection call and pass language to prompt builder
- AI prompt context: Inject language preference instruction

**Prompt Modification Strategy**:

The existing system prompt in `chat_stream()` will be enhanced with language-specific instructions:

```python
# Detect language
detected_language = detect_language(user_message)

# Add language instruction to context
if detected_language == "hinglish":
    language_instruction = """
LANGUAGE REQUIREMENT:
- User is communicating in HINGLISH (Hindi-English mix in Roman script)
- You MUST respond in HINGLISH using Roman script only
- Use natural Hinglish expressions like: "main samajh sakta hoon", "aap kaisa feel kar rahe hain", "tension mat lo"
- NEVER use Devanagari script (मैं, आप, etc.)
- Mix Hindi and English naturally as Indians do in informal conversation
"""
else:
    language_instruction = """
LANGUAGE REQUIREMENT:
- User is communicating in ENGLISH
- You MUST respond in clear, simple ENGLISH
"""

# Inject into existing context
context = base_context + language_instruction + conversation_history
```

**Bilingual Response Templates** (for rule-based fallback):

The existing `get_bot_response()` function will be extended with Hinglish versions of predefined responses:

```python
# Example structure
RESPONSES = {
    "crisis": {
        "english": "I'm really concerned about what you're sharing...",
        "hinglish": "Main aapki baat sunke bahut concerned hoon..."
    },
    "anxiety": {
        "english": ["Anxiety can feel overwhelming...", "That sounds stressful..."],
        "hinglish": ["Anxiety bahut overwhelming ho sakti hai...", "Ye bahut stressful lag raha hai..."]
    },
    # ... more categories
}
```

### 3. Chat Interface Enhancements

**Modified File**: `templates/chatbot/chat.html`

**Layout Changes**:

```html
<!-- Current: max-w-3xl -->
<!-- New: max-w-5xl -->
<div class="max-w-5xl mx-auto">
    
    <!-- Current: h-[350px] -->
    <!-- New: h-[500px] -->
    <div id="chatbot-messages" class="h-[500px] overflow-y-auto ...">
```

**Spacing Improvements**:

```css
/* Message text sizing */
.text-sm → .text-base (14px → 16px)

/* Message padding */
p-3 → p-4 (12px → 16px)

/* Message spacing */
space-y-3 → space-y-4 (12px → 16px between messages)
```

**Responsive Design Considerations**:

```html
<!-- Maintain responsive breakpoints -->
<div class="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8">
    <!-- On mobile: full width with padding -->
    <!-- On tablet: constrained to 5xl with side padding -->
    <!-- On desktop: full 5xl width utilized -->
</div>
```

**Bilingual Quick Actions**:

The quick action buttons will remain in Hinglish (as they currently are) since they serve as examples of how users can communicate. No changes needed here.

### 4. Safety and Crisis Detection

**Preservation Strategy**:

All safety features must work identically regardless of language:

```python
def check_crisis_keywords(message: str, language: str) -> bool:
    """Check for crisis keywords in both languages."""
    
    english_crisis = ["suicide", "kill myself", "end it", "harm", "hurt myself"]
    hinglish_crisis = ["suicide", "khud ko maar", "khatam kar", "harm", "khud ko hurt"]
    
    crisis_keywords = english_crisis + hinglish_crisis
    
    return any(word in message.lower() for word in crisis_keywords)
```

Crisis responses will be provided in the detected language but always include emergency contact information.

## Data Models

### Language Detection Data

**Hinglish Indicator Dictionary**:
```python
HINGLISH_INDICATORS = {
    # Verbs
    "kar", "karo", "karna", "karte", "karti", "kiya", "kiye",
    "hai", "hain", "hoon", "ho", "tha", "thi", "the", "thi",
    "raha", "rahi", "rahe", "rahein",
    
    # Question words
    "kya", "kaise", "kaisa", "kaisi", "kab", "kahan", "kyun", "kyu", "kaun",
    
    # Pronouns
    "mai", "main", "mujhe", "mera", "meri", "mere",
    "tu", "tum", "tumhe", "tumhara", "tumhari", "tumhare",
    "aap", "aapka", "aapki", "aapke",
    "hum", "humara", "humari", "humare",
    
    # Common words
    "nahi", "nahin", "na", "haan", "ha", "ji",
    "acha", "accha", "achha", "thik", "theek",
    "bahut", "bohot", "zyada", "jyada", "kam",
    "bhi", "bhe", "aur", "ya", "lekin", "par",
    
    # Mental health context
    "pareshan", "pareshaan", "tension", "stress",
    "dukh", "dard", "takleef", "mushkil",
    "khushi", "khush", "dar", "darr", "chinta",
    "neend", "sona", "jagana",
    
    # Common expressions
    "mat", "lo", "de", "do", "le", "lena", "dena",
    "samajh", "samajhna", "pata", "malum",
    "chahiye", "chaiye", "zaroor", "jaroor",
    "shayad", "shayd", "lagta", "lagte", "lagti"
}
```

**Language Detection Result**:
```python
# Simple string return
language: str  # "hinglish" or "english"
```

### Response Template Data Structure

```python
BILINGUAL_RESPONSES = {
    "category_name": {
        "english": [
            "Response option 1",
            "Response option 2"
        ],
        "hinglish": [
            "Hinglish response option 1",
            "Hinglish response option 2"
        ]
    }
}
```

### Message History Data (unchanged)

The existing localStorage structure remains the same:
```javascript
{
    sender: string,
    text: string,
    isUser: boolean,
    timestamp: string
}
```

No language field is added to message history since language is detected per-message dynamically.


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property 1: Language Detection Threshold

*For any* user message, when the message contains at least 20% Hinglish indicator words (from the predefined dictionary), the language detector should classify it as "hinglish", and when it contains less than 20% Hinglish words, it should classify it as "english".

**Validates: Requirements 1.3**

### Property 2: Language Detection Returns Valid Values

*For any* user message input (including empty strings, special characters, or very long text), the language detector should always return exactly one of two valid values: "hinglish" or "english", never null, undefined, or any other value.

**Validates: Requirements 1.4**

### Property 3: Response Language Matches Detection

*For any* user message that is detected as Hinglish, the generated response should contain Hinglish content (verified by presence of Hinglish indicator words or Roman script Hindi expressions), and for any message detected as English, the response should be in English.

**Validates: Requirements 2.1**

### Property 4: Bilingual Response Templates Exist

*For any* response category in the rule-based response system (crisis, anxiety, depression, loneliness, sleep, positive, self-care), both English and Hinglish response templates should exist and be non-empty.

**Validates: Requirements 2.5**

### Property 5: Crisis Detection Works in Both Languages

*For any* message containing crisis keywords (in either English or Hinglish), the system should trigger the crisis response protocol regardless of which language the keywords appear in, ensuring safety features are preserved across languages.

**Validates: Requirements 2.6, 6.1**

### Property 6: Language Consistency Across Conversation

*For any* sequence of messages where the user switches between English and Hinglish, the chatbot should respond in the language matching each individual message's detected language, demonstrating per-message language adaptation.

**Validates: Requirements 3.1, 3.2**

### Property 7: Conversation History Preserved Across Language Switches

*For any* conversation where the user switches languages, all previous messages (in both languages) should remain accessible in the chat history and localStorage, and the conversation context should be maintained without loss of information.

**Validates: Requirements 3.4**

### Property 8: Responsive Layout Adaptation

*For any* viewport width (mobile: <640px, tablet: 640-1024px, desktop: >1024px), the chat interface should adapt its layout appropriately with proper padding and spacing, ensuring the interface remains usable and properly formatted at all screen sizes.

**Validates: Requirements 4.4**

### Property 9: Visual Styling Preservation

*For any* existing CSS property related to visual styling (colors, gradients, shadows, borders, border-radius), the values should remain unchanged after the layout modifications, ensuring visual consistency with the existing design system.

**Validates: Requirements 4.6**

### Property 10: Minimum Spacing Requirements

*For any* message displayed in the chat interface, the padding within message bubbles should be at least 16px (p-4), and the spacing between consecutive messages should be at least 16px (space-y-4), ensuring adequate readability.

**Validates: Requirements 5.1**

### Property 11: Contrast Ratio Compliance

*For any* text and background color combination in the chat interface (message text on bubble background, timestamp text on page background), the contrast ratio should meet or exceed WCAG AA standards (4.5:1 for normal text, 3:1 for large text).

**Validates: Requirements 5.3**

### Property 12: Text Wrapping Without Overflow

*For any* message content including very long words or continuous text without spaces, the message should wrap properly within its container without causing horizontal scrolling in the messages area.

**Validates: Requirements 5.4**

### Property 13: No Element Overlap

*For any* message with timestamp and metadata, the timestamp element should not overlap with the message content text, verified by checking that the bounding boxes of these elements do not intersect.

**Validates: Requirements 5.5**

### Property 14: localStorage Persistence Round Trip

*For any* message sent in the chat (in either language), saving the message to localStorage and then loading it back should produce an equivalent message object with the same sender, text, isUser flag, and timestamp.

**Validates: Requirements 6.3**

### Property 15: Fallback Response Mode

*For any* scenario where AI services (Ollama, Google AI, OpenAI) are unavailable or return errors, the system should fall back to rule-based responses and continue functioning, ensuring the chatbot remains operational.

**Validates: Requirements 6.5**

### Property 16: Interactive Features Preservation

*For any* existing interactive feature (typing indicator, message animations, Lucide icons, quick action buttons), the feature should remain present and functional after the enhancements, verified by checking element existence and event handler attachment.

**Validates: Requirements 6.6**

## Error Handling

### Language Detection Errors

**Empty or Invalid Input**:
- Empty strings: Return "english" as default
- Null/undefined: Return "english" as default
- Very short messages (1-2 words): May have lower accuracy but will not error; acceptable given context

**Edge Cases**:
- All-caps input: Handle via case-insensitive matching
- Special characters and emojis: Ignore during tokenization
- Mixed scripts (Roman + Devanagari): Count only Roman script words

### Response Generation Errors

**AI Service Failures**:
- Ollama timeout: Fall back to rule-based responses
- API errors (Google AI, OpenAI): Fall back to rule-based responses
- Network errors: Display user-friendly error message, suggest retry

**Language Mismatch**:
- If AI generates response in wrong language: Accept it (AI may have good reason)
- If rule-based response missing for language: Fall back to English version

**Crisis Detection**:
- Always prioritize safety: If crisis detected, use crisis response regardless of other errors
- Crisis responses must work even if AI services are down
- Log all crisis detections for monitoring

### UI Rendering Errors

**Layout Issues**:
- Container overflow: Ensure overflow-y-auto on messages container
- Responsive breakpoint failures: Provide sensible defaults for all screen sizes
- Icon loading failures: Graceful degradation (show text labels if icons don't load)

**localStorage Errors**:
- Quota exceeded: Clear old messages (keep only last 50)
- localStorage unavailable: Continue functioning without persistence
- Parse errors: Clear corrupted data and start fresh

### Input Validation

**Message Length**:
- Maximum message length: 2000 characters (prevent abuse)
- Empty messages: Prevent submission via frontend validation
- Whitespace-only messages: Trim and reject if empty

**XSS Prevention**:
- Sanitize user input before displaying in chat
- Escape HTML special characters
- Use textContent instead of innerHTML where possible

## Testing Strategy

### Dual Testing Approach

This feature will be tested using both unit tests and property-based tests to ensure comprehensive coverage:

- **Unit tests**: Verify specific examples, edge cases, error conditions, and integration points
- **Property tests**: Verify universal properties across randomized inputs

Both testing approaches are complementary and necessary. Unit tests catch concrete bugs and verify specific scenarios, while property tests verify general correctness across a wide range of inputs.

### Property-Based Testing

**Framework**: We will use **Hypothesis** for Python (backend) and **fast-check** for JavaScript (frontend).

**Configuration**:
- Minimum 100 iterations per property test (due to randomization)
- Each property test must reference its design document property
- Tag format: `# Feature: hinglish-chatbot-improvements, Property {number}: {property_text}`

**Property Test Coverage**:

1. **Language Detection Properties** (Properties 1, 2):
   - Generate random messages with varying percentages of Hinglish words
   - Generate edge cases: empty strings, special characters, very long text
   - Verify threshold behavior and valid return values

2. **Response Generation Properties** (Properties 3, 4, 5):
   - Generate random Hinglish and English messages
   - Verify response language matches input language
   - Test crisis keyword detection with random message contexts
   - Verify bilingual template completeness

3. **Language Switching Properties** (Properties 6, 7):
   - Generate random conversation sequences with language switches
   - Verify response language consistency
   - Verify history preservation

4. **UI Properties** (Properties 8, 9, 10, 11, 12, 13, 16):
   - Generate random viewport sizes
   - Generate random message lengths and content
   - Verify layout adaptation, spacing, contrast, wrapping
   - Verify no element overlap

5. **Persistence Properties** (Properties 14, 15):
   - Generate random messages and verify localStorage round trip
   - Test fallback behavior with simulated AI failures

### Unit Testing

**Backend Unit Tests** (`test_chatbot.py`):

```python
# Language detection examples
def test_detect_language_pure_english():
    assert detect_language("I am feeling anxious") == "english"

def test_detect_language_pure_hinglish():
    assert detect_language("Main bahut pareshan hoon") == "hinglish"

def test_detect_language_mixed_below_threshold():
    assert detect_language("I am feeling thoda anxious") == "english"  # ~17%

def test_detect_language_mixed_above_threshold():
    assert detect_language("Main feeling bahut anxious hoon") == "hinglish"  # ~60%

def test_detect_language_empty():
    assert detect_language("") == "english"

# Crisis detection examples
def test_crisis_detection_english():
    response = get_bot_response("I want to kill myself")
    assert "988" in response or "crisis" in response.lower()

def test_crisis_detection_hinglish():
    response = get_bot_response("Main khud ko maar dena chahta hoon")
    assert "988" in response or "crisis" in response.lower()

# Response generation examples
def test_response_generation_with_language_context():
    # Test that language context is passed correctly
    # This would require mocking the AI service
    pass

# Bilingual templates
def test_bilingual_templates_exist():
    categories = ["crisis", "anxiety", "depression", "loneliness", "sleep"]
    for category in categories:
        assert category in BILINGUAL_RESPONSES
        assert "english" in BILINGUAL_RESPONSES[category]
        assert "hinglish" in BILINGUAL_RESPONSES[category]
```

**Frontend Unit Tests** (`chatbot.test.js`):

```javascript
// Layout dimensions
test('chat container uses max-w-5xl class', () => {
    const container = document.querySelector('.max-w-5xl');
    expect(container).toBeTruthy();
});

test('messages area has minimum 500px height', () => {
    const messagesArea = document.getElementById('chatbot-messages');
    const height = window.getComputedStyle(messagesArea).height;
    expect(parseInt(height)).toBeGreaterThanOrEqual(500);
});

// Font size
test('message text has minimum 14px font size', () => {
    const messageText = document.querySelector('.text-base');
    const fontSize = window.getComputedStyle(messageText).fontSize;
    expect(parseInt(fontSize)).toBeGreaterThanOrEqual(14);
});

// localStorage
test('clear chat removes localStorage data', () => {
    localStorage.setItem('chatbotHistory', JSON.stringify([{text: 'test'}]));
    clearChat();
    expect(localStorage.getItem('chatbotHistory')).toBeNull();
});

// Quick action buttons
test('quick action buttons exist and are clickable', () => {
    const buttons = document.querySelectorAll('.quick-action');
    expect(buttons.length).toBeGreaterThan(0);
    buttons.forEach(button => {
        expect(button.onclick || button.addEventListener).toBeTruthy();
    });
});
```

### Integration Testing

**End-to-End Scenarios**:

1. **Language Switching Flow**:
   - Send English message → Verify English response
   - Send Hinglish message → Verify Hinglish response
   - Send English message again → Verify English response
   - Check history contains all messages

2. **Crisis Detection Flow**:
   - Send crisis message in English → Verify crisis response
   - Send crisis message in Hinglish → Verify crisis response
   - Verify emergency contact info present

3. **AI Fallback Flow**:
   - Disable Ollama service
   - Send message → Verify rule-based response
   - Re-enable Ollama → Verify AI response

4. **Responsive Layout Flow**:
   - Load page at mobile width → Verify layout
   - Resize to tablet width → Verify layout adapts
   - Resize to desktop width → Verify layout adapts

### Manual Testing Checklist

- [ ] Visual inspection of layout at different screen sizes
- [ ] Verify color contrast meets WCAG standards using browser tools
- [ ] Test with screen reader to ensure accessibility
- [ ] Verify Hinglish responses sound natural to native speakers
- [ ] Test with various Hinglish input patterns and dialects
- [ ] Verify all animations and transitions work smoothly
- [ ] Test localStorage persistence across browser sessions
- [ ] Verify crisis detection with various phrasings

### Performance Testing

**Metrics to Monitor**:
- Language detection latency: < 5ms for typical messages
- Response generation latency: < 2s for AI responses, < 100ms for rule-based
- UI rendering: 60fps for animations and scrolling
- localStorage operations: < 10ms for save/load

**Load Testing**:
- Test with 100+ messages in history
- Test with very long messages (2000 characters)
- Test rapid message sending (stress test)

### Regression Testing

After implementation, verify that all existing features still work:
- Emotion detection page
- PHQ-9 and GAD-7 assessments
- Breathing exercise
- Dashboard
- All navigation links

