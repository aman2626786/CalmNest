# Implementation Plan: Hinglish Chatbot Improvements

## Overview

This implementation plan breaks down the Hinglish language support and UI improvements into discrete coding tasks. The approach follows a layered implementation: first establishing the language detection foundation, then enhancing response generation, followed by UI improvements, and finally integration and testing. Each task builds incrementally on previous work to ensure the chatbot remains functional throughout development.

## Tasks

- [ ] 1. Implement language detection module
  - [ ] 1.1 Create Hinglish indicator word dictionary in app.py
    - Define HINGLISH_INDICATORS set with common Hinglish words (verbs, question words, pronouns, mental health terms)
    - Include word variations and common spellings (e.g., "acha", "accha", "achha")
    - _Requirements: 1.2_
  
  - [ ] 1.2 Implement detect_language() function
    - Create function that tokenizes message and counts Hinglish words
    - Calculate percentage of Hinglish words in message
    - Return "hinglish" if >= 20% threshold, else "english"
    - Handle edge cases: empty strings, special characters, case-insensitive matching
    - _Requirements: 1.1, 1.3, 1.4, 1.5_
  
  - [ ]* 1.3 Write property test for language detection threshold
    - **Property 1: Language Detection Threshold**
    - **Validates: Requirements 1.3**
    - Generate random messages with varying percentages of Hinglish words
    - Verify classification matches 20% threshold rule
  
  - [ ]* 1.4 Write property test for valid return values
    - **Property 2: Language Detection Returns Valid Values**
    - **Validates: Requirements 1.4**
    - Generate edge cases: empty strings, special characters, very long text
    - Verify function always returns "hinglish" or "english"
  
  - [ ]* 1.5 Write unit tests for language detection examples
    - Test pure English messages return "english"
    - Test pure Hinglish messages return "hinglish"
    - Test mixed messages above and below threshold
    - Test empty string returns "english"

- [ ] 2. Enhance response generation with bilingual support
  - [ ] 2.1 Create bilingual response templates dictionary
    - Define BILINGUAL_RESPONSES dictionary with categories: crisis, anxiety, depression, loneliness, sleep, positive, self-care
    - Add English and Hinglish response arrays for each category
    - Ensure natural Hinglish expressions (e.g., "main samajh sakta hoon", "tension mat lo")
    - _Requirements: 2.5, 2.7_
  
  - [ ]* 2.2 Write property test for bilingual template completeness
    - **Property 4: Bilingual Response Templates Exist**
    - **Validates: Requirements 2.5**
    - Verify all response categories have both English and Hinglish templates
    - Verify templates are non-empty
  
  - [ ] 2.3 Modify get_bot_response() to use language parameter
    - Add language parameter to function signature
    - Update response selection to use language-specific templates from BILINGUAL_RESPONSES
    - Maintain existing fallback logic
    - _Requirements: 2.1, 2.5_
  
  - [ ] 2.4 Enhance crisis detection with bilingual keywords
    - Extend crisis keyword list to include Hinglish terms ("khud ko maar", "khatam kar")
    - Ensure crisis detection works regardless of language
    - _Requirements: 2.6, 6.1_
  
  - [ ]* 2.5 Write property test for crisis detection in both languages
    - **Property 5: Crisis Detection Works in Both Languages**
    - **Validates: Requirements 2.6, 6.1**
    - Generate random messages with crisis keywords in English and Hinglish
    - Verify crisis response triggered for both languages

- [ ] 3. Integrate language detection into chat endpoint
  - [ ] 3.1 Modify chat_stream() to call detect_language()
    - Add language detection call at beginning of chat_stream() function
    - Pass detected language to response generation logic
    - _Requirements: 1.5, 3.3_
  
  - [ ] 3.2 Add language instruction to AI prompt context
    - Create language-specific instruction strings for Hinglish and English
    - Inject language instruction into system prompt for Ollama/Google AI/OpenAI
    - Ensure instruction emphasizes Roman script for Hinglish (no Devanagari)
    - _Requirements: 2.1, 2.4_
  
  - [ ] 3.3 Update response generation to pass language parameter
    - Pass detected language to get_bot_response() for rule-based responses
    - Ensure language context flows through entire response pipeline
    - _Requirements: 2.1, 3.1, 3.2_
  
  - [ ]* 3.4 Write property test for response language matching
    - **Property 3: Response Language Matches Detection**
    - **Validates: Requirements 2.1**
    - Generate random Hinglish and English messages
    - Verify response contains appropriate language indicators
  
  - [ ]* 3.5 Write property test for language consistency
    - **Property 6: Language Consistency Across Conversation**
    - **Validates: Requirements 3.1, 3.2**
    - Generate conversation sequences with language switches
    - Verify each response matches its message's detected language

- [ ] 4. Checkpoint - Ensure language detection and response generation work
  - Ensure all tests pass, ask the user if questions arise.

- [-] 5. Implement UI layout improvements
  - [ ] 5.1 Expand chat container width in chat.html
    - Change max-w-3xl to max-w-5xl on main chat container div
    - Maintain responsive padding classes (px-4 sm:px-6 lg:px-8)
    - _Requirements: 4.1, 4.5_
  
  - [ ] 5.2 Increase message display area height
    - Change h-[350px] to h-[500px] on chatbot-messages div
    - Ensure overflow-y-auto remains for scrolling
    - _Requirements: 4.2_
  
  - [ ] 5.3 Improve message spacing and typography
    - Update message text from text-sm to text-base (14px → 16px)
    - Update message padding from p-3 to p-4 (12px → 16px)
    - Update message spacing from space-y-3 to space-y-4 (12px → 16px)
    - _Requirements: 5.1, 5.2_
  
  - [ ]* 5.4 Write property test for responsive layout adaptation
    - **Property 8: Responsive Layout Adaptation**
    - **Validates: Requirements 4.4**
    - Generate random viewport sizes (mobile, tablet, desktop)
    - Verify layout adapts with proper padding and spacing
  
  - [ ]* 5.5 Write property test for minimum spacing requirements
    - **Property 10: Minimum Spacing Requirements**
    - **Validates: Requirements 5.1**
    - Verify message padding is at least 16px
    - Verify spacing between messages is at least 16px

- [ ] 6. Verify UI accessibility and styling preservation
  - [ ]* 6.1 Write property test for contrast ratio compliance
    - **Property 11: Contrast Ratio Compliance**
    - **Validates: Requirements 5.3**
    - Test text/background color combinations
    - Verify WCAG AA compliance (4.5:1 for normal text)
  
  - [ ]* 6.2 Write property test for text wrapping
    - **Property 12: Text Wrapping Without Overflow**
    - **Validates: Requirements 5.4**
    - Generate messages with very long words
    - Verify no horizontal scrolling occurs
  
  - [ ]* 6.3 Write property test for no element overlap
    - **Property 13: No Element Overlap**
    - **Validates: Requirements 5.5**
    - Verify timestamp doesn't overlap message content
    - Check bounding boxes don't intersect
  
  - [ ]* 6.4 Write property test for visual styling preservation
    - **Property 9: Visual Styling Preservation**
    - **Validates: Requirements 4.6**
    - Verify colors, gradients, shadows, borders remain unchanged
    - Compare computed styles before and after changes

- [ ] 7. Implement conversation history and persistence features
  - [ ] 7.1 Verify localStorage functionality with language switching
    - Test that messages in both languages are saved correctly
    - Ensure conversation history persists across language switches
    - _Requirements: 3.4, 6.3_
  
  - [ ]* 7.2 Write property test for localStorage round trip
    - **Property 14: localStorage Persistence Round Trip**
    - **Validates: Requirements 6.3**
    - Generate random messages in both languages
    - Verify save and load produces equivalent message objects
  
  - [ ]* 7.3 Write property test for conversation history preservation
    - **Property 7: Conversation History Preserved Across Language Switches**
    - **Validates: Requirements 3.4**
    - Generate conversation with language switches
    - Verify all messages remain accessible in history

- [ ] 8. Implement fallback and error handling
  - [ ] 8.1 Enhance error handling for AI service failures
    - Ensure fallback to rule-based responses when Ollama/AI unavailable
    - Add appropriate error messages for network failures
    - _Requirements: 6.5_
  
  - [ ]* 8.2 Write property test for fallback response mode
    - **Property 15: Fallback Response Mode**
    - **Validates: Requirements 6.5**
    - Simulate AI service failures
    - Verify system falls back to rule-based responses
  
  - [ ] 8.3 Add input validation for message length and content
    - Implement 2000 character maximum for messages
    - Prevent empty or whitespace-only message submission
    - Sanitize user input to prevent XSS

- [ ] 9. Verify backward compatibility and existing features
  - [ ]* 9.1 Write property test for interactive features preservation
    - **Property 16: Interactive Features Preservation**
    - **Validates: Requirements 6.6**
    - Verify typing indicator, animations, icons, quick action buttons exist
    - Check event handlers are attached
  
  - [ ]* 9.2 Write unit tests for existing functionality
    - Test quick action buttons remain functional
    - Test clear chat functionality works
    - Test localStorage clear operation
    - Verify all navigation links work
  
  - [ ] 9.3 Manual regression testing checklist
    - Test emotion detection page still works
    - Test PHQ-9 and GAD-7 assessments function correctly
    - Test breathing exercise page
    - Verify dashboard displays correctly
    - Test all navigation between pages

- [ ] 10. Final checkpoint - Comprehensive testing and validation
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests validate universal correctness properties across randomized inputs
- Unit tests validate specific examples and edge cases
- The implementation uses Python for backend (Flask) and JavaScript for frontend
- Language detection is rule-based (no ML dependencies required)
- All safety features must work identically in both English and Hinglish
- UI changes are CSS-based and maintain responsive design principles
