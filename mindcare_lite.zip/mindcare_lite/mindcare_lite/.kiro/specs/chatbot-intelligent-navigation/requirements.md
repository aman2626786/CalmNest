# Requirements Document

## Introduction

This feature adds intelligent navigation and redirection capabilities to the CalmNest chatbot. The chatbot will understand user requests in Hinglish (Hindi-English mix) and automatically redirect users to appropriate pages based on their intent, such as breathing exercises, mental health assessments (PHQ-9, GAD-7), emotion detection, and dashboard access.

## Glossary

- **Chatbot**: The conversational AI assistant named "Priya" that interacts with users on the CalmNest mental health website
- **Navigation_System**: The intelligent component that analyzes user messages and determines appropriate page redirects
- **Intent_Classifier**: The component that identifies user intent from natural language input in Hinglish
- **Redirect_Handler**: The component that executes navigation to target pages based on identified intent
- **Hinglish**: A mixed language combining Hindi and English commonly used in Indian communication
- **Page_Registry**: A configuration or data structure containing all available pages and their associated intents
- **PHQ-9**: Patient Health Questionnaire-9, a depression screening assessment
- **GAD-7**: Generalized Anxiety Disorder-7, an anxiety screening assessment

## Requirements

### Requirement 1: Intent Recognition for Page Navigation

**User Story:** As a user, I want the chatbot to understand when I'm asking to access specific features, so that I can quickly navigate to the right page without manually searching.

#### Acceptance Criteria

1. WHEN a user message contains breathing-related keywords (e.g., "breathing exercise", "breathe", "saans", "pranayam"), THE Intent_Classifier SHALL identify the intent as "breathing_exercise"
2. WHEN a user message contains PHQ-9 related keywords (e.g., "PHQ-9", "depression test", "depression check", "mood test"), THE Intent_Classifier SHALL identify the intent as "phq9_assessment"
3. WHEN a user message contains GAD-7 related keywords (e.g., "GAD-7", "anxiety test", "anxiety check", "ghabrahat test"), THE Intent_Classifier SHALL identify the intent as "gad7_assessment"
4. WHEN a user message contains emotion detection keywords (e.g., "emotion detection", "face scan", "mood detection", "emotion check"), THE Intent_Classifier SHALL identify the intent as "emotion_detection"
5. WHEN a user message contains dashboard keywords (e.g., "dashboard", "my progress", "history", "reports"), THE Intent_Classifier SHALL identify the intent as "dashboard_access"
6. THE Intent_Classifier SHALL recognize keywords in both Hindi and English within the same message
7. THE Intent_Classifier SHALL handle common Hinglish variations and transliterations

### Requirement 2: Automatic Page Redirection

**User Story:** As a user, I want to be automatically redirected to the appropriate page when I express intent, so that I can access features quickly without extra clicks.

#### Acceptance Criteria

1. WHEN the Intent_Classifier identifies "breathing_exercise" intent, THE Redirect_Handler SHALL navigate the user to the /breathe page
2. WHEN the Intent_Classifier identifies "phq9_assessment" intent, THE Redirect_Handler SHALL navigate the user to the /phq9 page
3. WHEN the Intent_Classifier identifies "gad7_assessment" intent, THE Redirect_Handler SHALL navigate the user to the /gad7 page
4. WHEN the Intent_Classifier identifies "emotion_detection" intent, THE Redirect_Handler SHALL navigate the user to the /emotion page
5. WHEN the Intent_Classifier identifies "dashboard_access" intent, THE Redirect_Handler SHALL navigate the user to the /dashboard page
6. WHEN no navigation intent is identified, THE Chatbot SHALL respond conversationally without triggering a redirect
7. THE Redirect_Handler SHALL execute navigation within 500ms of intent identification

### Requirement 3: Page Registry and Feature Discovery

**User Story:** As a developer, I want the chatbot to maintain a registry of all available pages and features, so that the system can be easily extended with new navigation targets.

#### Acceptance Criteria

1. THE Navigation_System SHALL maintain a Page_Registry containing all available navigation targets
2. FOR EACH page in the Page_Registry, THE Navigation_System SHALL store the page URL, associated keywords, and intent category
3. WHEN a new page is added to the application, THE Page_Registry SHALL be updatable without modifying core chatbot logic
4. THE Page_Registry SHALL include at minimum: /breathe, /phq9, /gad7, /emotion, /dashboard pages
5. THE Navigation_System SHALL support both English and Hindi keywords for each page in the Page_Registry

### Requirement 4: Conversational Redirect Confirmation

**User Story:** As a user, I want the chatbot to acknowledge my request before redirecting me, so that I understand what's happening and feel in control.

#### Acceptance Criteria

1. WHEN a navigation intent is identified, THE Chatbot SHALL send a confirmation message before redirecting
2. THE Chatbot SHALL include the target feature name in the confirmation message
3. THE Chatbot SHALL use Hinglish language in confirmation messages to match user communication style
4. THE confirmation message SHALL be displayed for at least 1 second before redirect execution
5. THE Chatbot SHALL provide a clickable link or button in the confirmation message as an alternative to automatic redirect

### Requirement 5: Hinglish Language Understanding

**User Story:** As a Hindi-English bilingual user, I want to communicate naturally in Hinglish, so that I can express myself comfortably without language barriers.

#### Acceptance Criteria

1. THE Intent_Classifier SHALL recognize common Hindi words for breathing (e.g., "saans", "pranayam", "breathing")
2. THE Intent_Classifier SHALL recognize common Hindi words for anxiety (e.g., "ghabrahat", "tension", "chinta")
3. THE Intent_Classifier SHALL recognize common Hindi words for depression (e.g., "udaasi", "depression", "mood")
4. THE Intent_Classifier SHALL handle code-switching between Hindi and English within a single message
5. THE Intent_Classifier SHALL recognize transliterated Hindi words in Roman script
6. WHEN responding with navigation confirmations, THE Chatbot SHALL use Hinglish phrases that match the user's language style

### Requirement 6: Fallback and Error Handling

**User Story:** As a user, I want helpful guidance when my request is unclear, so that I can successfully navigate to my desired feature.

#### Acceptance Criteria

1. WHEN the Intent_Classifier cannot determine a clear navigation intent, THE Chatbot SHALL respond conversationally without attempting redirect
2. WHEN multiple navigation intents are detected in a single message, THE Chatbot SHALL ask for clarification
3. IF a redirect fails due to technical error, THEN THE Chatbot SHALL inform the user and provide a manual link to the target page
4. WHEN a user asks "what can you do" or similar queries, THE Chatbot SHALL list all available navigation features
5. THE Chatbot SHALL maintain conversation context and not lose previous messages when handling navigation requests

### Requirement 7: Integration with Existing Chatbot

**User Story:** As a developer, I want the navigation feature to integrate seamlessly with the existing chatbot, so that current functionality remains unaffected.

#### Acceptance Criteria

1. THE Navigation_System SHALL integrate with the existing /chat-stream endpoint without breaking current functionality
2. THE Navigation_System SHALL preserve existing chat history and localStorage functionality
3. WHEN no navigation intent is detected, THE Chatbot SHALL continue to use the existing Ollama-based response generation
4. THE Navigation_System SHALL work alongside existing quick action buttons without conflicts
5. THE Chatbot SHALL maintain its current personality and safety guidelines while adding navigation capabilities
