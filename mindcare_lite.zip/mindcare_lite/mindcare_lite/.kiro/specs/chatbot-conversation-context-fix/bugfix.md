# Bugfix Requirements Document

## Introduction

The CalmNest mental health chatbot has two critical bugs that severely impact its ability to provide appropriate support to vulnerable users:

1. **Conversation context is not maintained**: Each user message is treated independently without awareness of previous messages in the conversation, making the chatbot unable to provide contextually relevant responses.

2. **Inappropriate responses to vulnerable users**: When users express severe distress (e.g., "I have no one to talk to" after showing PHQ-9 score of 27 indicating severe depression), the chatbot responds with dismissive messages like "I cannot provide a response that may perpetuate negative stereotypes or stigma around mental health" instead of providing empathetic support.

These bugs represent a critical safety issue for a mental health support application, as they prevent the chatbot from providing appropriate, context-aware, and empathetic responses to users in distress.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a user sends multiple messages in a conversation THEN the chatbot treats each message independently without awareness of previous messages

1.2 WHEN a user shares their PHQ-9 score of 27 (severe depression) and then says "mere pas bat karne ke liye koi nhi ha" (I have no one to talk to) THEN the chatbot responds with "I cannot provide a response that may perpetuate negative stereotypes or stigma around mental health" instead of providing empathetic support

1.3 WHEN the frontend sends a message to the backend THEN only the current message text is sent without the conversation history stored in localStorage

1.4 WHEN the backend receives a message THEN it maintains chat_history in memory but this history is not synchronized with the frontend's localStorage history

1.5 WHEN a user expresses vulnerability or distress THEN the chatbot's overly restrictive safety filters cause it to refuse providing support instead of offering empathetic responses

1.6 WHEN conversations are stored in localStorage THEN they are lost when the browser session ends or localStorage is cleared, preventing the chatbot from accessing historical context

1.7 WHEN the backend needs to retrieve previous conversation context THEN it has no persistent file-based storage to read from, limiting the chatbot's memory to the current session only

### Expected Behavior (Correct)

2.1 WHEN a user sends multiple messages in a conversation THEN the chatbot SHALL maintain awareness of previous messages and provide contextually relevant responses that reference earlier parts of the conversation

2.2 WHEN a user shares their PHQ-9 score of 27 (severe depression) and then says "mere pas bat karne ke liye koi nhi ha" (I have no one to talk to) THEN the chatbot SHALL respond with empathetic support acknowledging their feelings of loneliness and their severe depression score

2.3 WHEN the frontend sends a message to the backend THEN it SHALL include the relevant conversation history from localStorage so the backend can provide context-aware responses

2.4 WHEN the backend receives a message with conversation history THEN it SHALL use this history to build the context for the LLM prompt and maintain continuity in the conversation

2.5 WHEN a user expresses vulnerability or distress THEN the chatbot SHALL provide warm, empathetic, and supportive responses while maintaining appropriate safety boundaries for crisis situations

2.6 WHEN a user sends a message THEN the system SHALL persist the conversation (user message, bot response, timestamp, and assessment scores if available) to a user-specific file for long-term storage

2.7 WHEN the backend needs conversation context THEN it SHALL read from the user's conversation file to retrieve full conversation history beyond the current session

2.8 WHEN a conversation file is updated THEN it SHALL append new messages with their metadata (timestamp, assessment scores) in a structured format that can be easily parsed

2.9 WHEN the chatbot generates a response THEN it SHALL have access to all previous interactions from the conversation file, giving it strong memory across sessions

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a user sends their first message in a new conversation THEN the chatbot SHALL CONTINUE TO respond appropriately with the welcome greeting and initial support

3.2 WHEN a user mentions crisis keywords like "suicide" or "self-harm" THEN the chatbot SHALL CONTINUE TO follow the crisis protocol and provide helpline numbers immediately

3.3 WHEN the chat history is cleared using the "Clear" button THEN the system SHALL CONTINUE TO clear both localStorage and server-side history (including the conversation file)

3.4 WHEN messages are displayed in the UI THEN they SHALL CONTINUE TO show with proper formatting, timestamps, and visual styling

3.5 WHEN the backend streams responses THEN it SHALL CONTINUE TO stream tokens progressively to the frontend for real-time display

3.6 WHEN the conversation history exceeds the maximum limit THEN the system SHALL CONTINUE TO keep only the most recent messages to prevent memory issues

3.7 WHEN multiple users access the chatbot THEN each user's conversation file SHALL remain isolated and secure from other users
