# Bugfix Requirements Document

## Introduction

The CalmNest chatbot is experiencing slow response times when using the local Llama 3.2:3b model via Ollama. Users expect quick, conversational responses but are experiencing delays that make the chatbot feel unresponsive. The root cause is an oversized system prompt (~450+ lines) combined with suboptimal model parameters that are not tuned for a smaller local model. This fix will optimize the prompt size and model parameters to achieve faster response times while maintaining the chatbot's supportive mental health assistance capabilities.

## Bug Analysis

### Current Behavior (Defect)

1.1 WHEN a user sends any message to the chatbot THEN the system sends an extremely large system prompt (~450+ lines of instructions) to Ollama with every request, causing slow processing

1.2 WHEN the chatbot generates a response THEN the system uses num_predict=150 tokens which forces the model to generate longer responses, increasing latency

1.3 WHEN the chatbot processes context THEN the system uses num_ctx=1024 which processes more context than necessary for a 3b parameter model, slowing down inference

1.4 WHEN multiple messages are exchanged THEN the system includes chat history on top of the already massive prompt, further increasing processing time

### Expected Behavior (Correct)

2.1 WHEN a user sends any message to the chatbot THEN the system SHALL send a concise, optimized system prompt (under 100 lines) that contains only essential instructions for mental health support

2.2 WHEN the chatbot generates a response THEN the system SHALL use num_predict=80-100 tokens to generate concise, helpful responses faster without sacrificing quality

2.3 WHEN the chatbot processes context THEN the system SHALL use num_ctx=512 which is sufficient for the conversation while optimized for the 3b parameter model's capabilities

2.4 WHEN multiple messages are exchanged THEN the system SHALL include only the last 1-2 message pairs in context to minimize prompt size while maintaining conversation continuity

### Unchanged Behavior (Regression Prevention)

3.1 WHEN a user mentions crisis keywords (suicide, self-harm, etc.) THEN the system SHALL CONTINUE TO provide immediate crisis support with helpline numbers

3.2 WHEN a user writes in English THEN the system SHALL CONTINUE TO respond in English

3.3 WHEN a user writes in Hindi or Hinglish THEN the system SHALL CONTINUE TO respond in Hinglish (Roman script only)

3.4 WHEN a user asks for medical diagnosis or medication THEN the system SHALL CONTINUE TO decline and redirect to professional help

3.5 WHEN a user asks about CalmNest features THEN the system SHALL CONTINUE TO suggest appropriate features (Breathing Exercise, PHQ-9, GAD-7, etc.)

3.6 WHEN the chatbot responds THEN the system SHALL CONTINUE TO maintain a warm, supportive, and emotionally intelligent tone

3.7 WHEN streaming responses THEN the system SHALL CONTINUE TO display tokens progressively in the frontend as they arrive
