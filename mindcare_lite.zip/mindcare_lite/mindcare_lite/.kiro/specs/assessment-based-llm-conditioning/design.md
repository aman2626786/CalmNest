# Design Document: Assessment-Based LLM Conditioning

## Overview

This feature integrates PHQ-9 (depression) and GAD-7 (anxiety) assessment results with the Ollama-based chatbot to provide personalized, severity-appropriate mental health support. The system calculates assessment scores, classifies severity levels, persists results to browser localStorage, and dynamically conditions the LLM's system prompt to match the user's mental health state.

### Key Design Goals

1. **Seamless Integration**: Assessment results flow automatically into chatbot context without user intervention
2. **Safety-First**: Severity-based conditioning ensures appropriate tone and recommendations for each mental health state
3. **Immediate Feedback**: Users receive an automatic LLM-generated response immediately after completing assessments
4. **Stateless Backend**: Leverage browser localStorage for persistence, keeping the Flask backend simple
5. **Transparent Context**: Users can see their current assessment status in the chatbot interface

### Research Context

Mental health chatbots require careful calibration based on symptom severity. Research in digital mental health interventions shows that:

- **Severity-Appropriate Responses**: Users with severe symptoms need crisis resources and professional referrals, while those with minimal symptoms benefit from preventive strategies
- **Standardized Assessments**: PHQ-9 and GAD-7 are clinically validated, widely used screening tools with established severity thresholds
- **Prompt Engineering for Safety**: LLM system prompts can be conditioned to maintain appropriate boundaries, avoid harmful advice, and prioritize user safety
- **Immediate Engagement**: Providing instant feedback after assessment completion increases user engagement and perceived support

## Architecture

### System Components


```
┌─────────────────────────────────────────────────────────────────┐
│                        Browser (Client)                          │
├─────────────────────────────────────────────────────────────────┤
│                                                                   │
│  ┌──────────────┐      ┌──────────────┐      ┌──────────────┐  │
│  │  PHQ-9 Form  │      │  GAD-7 Form  │      │   Chatbot    │  │
│  │              │      │              │      │   Interface  │  │
│  │  - Collects  │      │  - Collects  │      │              │  │
│  │    responses │      │    responses │      │  - Displays  │  │
│  │  - Validates │      │  - Validates │      │    messages  │  │
│  │  - Calculates│      │  - Calculates│      │  - Shows     │  │
│  │    score     │      │    score     │      │    status    │  │
│  │  - Classifies│      │  - Classifies│      │              │  │
│  │    severity  │      │    severity  │      │              │  │
│  └──────┬───────┘      └──────┬───────┘      └──────┬───────┘  │
│         │                     │                     │           │
│         └─────────────────────┴─────────────────────┘           │
│                               │                                 │
│                    ┌──────────▼──────────┐                      │
│                    │   localStorage      │                      │
│                    │                     │                      │
│                    │  - phq9Data: []     │                      │
│                    │  - gad7Data: []     │                      │
│                    │  - chatbotHistory   │                      │
│                    └──────────┬──────────┘                      │
│                               │                                 │
└───────────────────────────────┼─────────────────────────────────┘
                                │
                    ┌───────────▼───────────┐
                    │   Flask Backend       │
                    │                       │
                    │  /chat-stream         │
                    │  - Retrieves latest   │
                    │    assessment data    │
                    │  - Builds conditioned │
                    │    system prompt      │
                    │  - Streams response   │
                    │                       │
                    └───────────┬───────────┘
                                │
                    ┌───────────▼───────────┐
                    │   Ollama API          │
                    │                       │
                    │  - Receives prompt    │
                    │  - Generates response │
                    │  - Streams tokens     │
                    └───────────────────────┘
```

### Component Responsibilities

**Assessment Forms (Client-Side JavaScript)**
- Validate user responses (all questions answered, values 0-3)
- Calculate total scores using simple summation
- Classify severity based on score thresholds
- Persist results to localStorage with timestamps
- Trigger automatic chatbot response generation
- Display processing indicator during LLM generation


**Chatbot Interface (Client-Side JavaScript)**
- Retrieve latest assessment results from localStorage on page load
- Display assessment status (severity levels, scores, dates) in UI
- Send assessment context to backend with each chat message
- Handle streaming responses from backend
- Provide links to assessment pages

**Flask Backend (/chat-stream endpoint)**
- Accept chat messages with optional assessment context
- Build severity-conditioned system prompts
- Forward requests to Ollama API
- Stream responses back to client
- Remain stateless (no server-side session storage)

**Ollama LLM**
- Generate responses based on conditioned system prompts
- Maintain conversation context within request
- Stream tokens for real-time display

### Data Flow

1. **Assessment Submission Flow**
   - User completes PHQ-9 or GAD-7 form
   - JavaScript validates all responses present and in range [0-3]
   - JavaScript calculates total score
   - JavaScript classifies severity using threshold rules
   - JavaScript saves to localStorage: `{score, severity, timestamp, type}`
   - JavaScript shows processing indicator
   - JavaScript sends automatic message to chatbot with assessment context
   - Backend generates severity-appropriate response
   - Response displayed on results page

2. **Chatbot Interaction Flow**
   - User opens chatbot interface
   - JavaScript retrieves latest PHQ-9 and GAD-7 results from localStorage
   - JavaScript displays assessment status in UI
   - User sends message
   - JavaScript includes assessment context in request payload
   - Backend builds conditioned system prompt based on severity
   - Backend forwards to Ollama with full context
   - Backend streams response tokens back to client
   - Client displays streaming response in real-time


## Components and Interfaces

### Client-Side Assessment Module

**Location**: `templates/phq9.html`, `templates/gad7.html` (JavaScript sections)

**Functions**:

```javascript
// Calculate PHQ-9 score from form responses
function calculatePHQ9Score(responses: number[]): number
  Input: Array of 9 integers [0-3]
  Output: Sum of all responses [0-27]
  
// Classify PHQ-9 severity
function classifyPHQ9Severity(score: number): string
  Input: Score [0-27]
  Output: "Minimal" | "Mild" | "Moderate" | "Moderately_Severe" | "Severe"
  Rules:
    0-4: Minimal
    5-9: Mild
    10-14: Moderate
    15-19: Moderately_Severe
    20-27: Severe

// Calculate GAD-7 score from form responses
function calculateGAD7Score(responses: number[]): number
  Input: Array of 7 integers [0-3]
  Output: Sum of all responses [0-21]

// Classify GAD-7 severity
function classifyGAD7Severity(score: number): string
  Input: Score [0-21]
  Output: "Minimal" | "Mild" | "Moderate" | "Severe"
  Rules:
    0-4: Minimal
    5-9: Mild
    10-14: Moderate
    15-21: Severe

// Save assessment result to localStorage
function saveAssessmentResult(type: string, score: number, severity: string): void
  Input: Assessment type ("PHQ-9" | "GAD-7"), score, severity level
  Side Effect: Appends to localStorage array (phq9Data or gad7Data)
  Format: {score: number, severity: string, timestamp: ISO8601, type: string}

// Trigger automatic chatbot response after assessment
async function generateAutomaticResponse(assessmentType: string, score: number, severity: string): Promise<void>
  Input: Assessment type, score, severity
  Side Effect: 
    - Shows processing indicator
    - Sends message to /chat-stream with assessment context
    - Displays response on results page
    - Hides processing indicator
```


### Client-Side Chatbot Module

**Location**: `templates/chatbot/chat.html` (JavaScript section)

**Functions**:

```javascript
// Retrieve latest assessment results from localStorage
function getLatestAssessments(): {phq9: AssessmentResult | null, gad7: AssessmentResult | null}
  Output: Most recent PHQ-9 and GAD-7 results (or null if none exist)
  Logic: Parse localStorage arrays, sort by timestamp descending, take first element

// Display assessment status in chatbot UI
function displayAssessmentStatus(phq9: AssessmentResult | null, gad7: AssessmentResult | null): void
  Input: Latest assessment results
  Side Effect: Updates DOM to show severity levels, scores, and dates
  If no assessments: Display message encouraging user to complete assessments

// Build assessment context for backend
function buildAssessmentContext(): object
  Output: {phq9Score: number, phq9Severity: string, gad7Score: number, gad7Severity: string} | null
  Logic: Retrieve latest assessments, format for backend consumption

// Send message with assessment context
async function sendMessage(message: string, assessmentContext: object | null): Promise<void>
  Input: User message, assessment context
  Side Effect: POST to /chat-stream with {message, assessmentContext}
```

**Data Structures**:

```typescript
interface AssessmentResult {
  score: number;
  severity: string;
  timestamp: string; // ISO8601
  type: "PHQ-9" | "GAD-7";
}
```


### Backend LLM Conditioning Module

**Location**: `app.py`

**Functions**:

```python
def build_conditioned_prompt(
    user_message: str,
    phq9_score: int | None,
    phq9_severity: str | None,
    gad7_score: int | None,
    gad7_severity: str | None,
    chat_history: list
) -> str:
    """
    Build system prompt conditioned on assessment severity.
    
    Args:
        user_message: Current user message
        phq9_score: PHQ-9 score (0-27) or None
        phq9_severity: PHQ-9 severity level or None
        gad7_score: GAD-7 score (0-21) or None
        gad7_severity: GAD-7 severity level or None
        chat_history: Recent conversation history
        
    Returns:
        Complete prompt string for Ollama
        
    Logic:
        1. Start with base CalmNest system prompt
        2. If assessments exist, inject severity context
        3. Determine highest severity level across both assessments
        4. Add severity-specific instructions:
           - Minimal: Encouraging, wellness-focused, preventive
           - Mild: Supportive, practical coping strategies
           - Moderate/Moderately_Severe: Empathetic, recommend professional help
           - Severe: Compassionate, crisis-aware, strong professional referral
        5. Include specific scores for context
        6. Append conversation history
        7. Add user message
    """

def determine_overall_severity(phq9_severity: str | None, gad7_severity: str | None) -> str:
    """
    Determine overall severity from both assessments.
    
    Args:
        phq9_severity: PHQ-9 severity level or None
        gad7_severity: GAD-7 severity level or None
        
    Returns:
        Highest severity level: "Minimal" | "Mild" | "Moderate" | "Severe"
        
    Logic:
        - Map Moderately_Severe to Moderate for simplicity
        - Return highest severity between both assessments
        - If only one exists, use that one
        - If neither exists, return "Minimal" (default)
        
    Severity ordering: Severe > Moderate > Mild > Minimal
    """
```


**API Endpoint**:

```python
@app.route("/chat-stream", methods=["POST"])
def chat_stream():
    """
    Streaming chat endpoint with assessment-based conditioning.
    
    Request Body:
        {
            "message": str,
            "assessmentContext": {
                "phq9Score": int | null,
                "phq9Severity": str | null,
                "gad7Score": int | null,
                "gad7Severity": str | null
            } | null
        }
        
    Response:
        Streaming text/plain response (token by token)
        
    Process:
        1. Extract message and assessment context from request
        2. Add user message to chat history
        3. Build conditioned prompt using assessment context
        4. Send to Ollama API with streaming enabled
        5. Stream response tokens back to client
        6. Save assistant response to chat history
    """
```

## Data Models

### localStorage Schema

**phq9Data** (Array):
```json
[
  {
    "score": 12,
    "severity": "Moderate",
    "timestamp": "2024-01-15T14:30:00.000Z",
    "type": "PHQ-9"
  }
]
```

**gad7Data** (Array):
```json
[
  {
    "score": 8,
    "severity": "Mild",
    "timestamp": "2024-01-15T14:35:00.000Z",
    "type": "GAD-7"
  }
]
```

**chatbotHistory** (Array):
```json
[
  {
    "sender": "You",
    "text": "I'm feeling anxious today",
    "isUser": true,
    "timestamp": "2:30 PM"
  },
  {
    "sender": "Bot",
    "text": "I understand you're feeling anxious...",
    "isUser": false,
    "timestamp": "2:30 PM"
  }
]
```


### Severity Classification Rules

**PHQ-9 (Depression)**:
- Score 0-4: Minimal
- Score 5-9: Mild
- Score 10-14: Moderate
- Score 15-19: Moderately_Severe
- Score 20-27: Severe

**GAD-7 (Anxiety)**:
- Score 0-4: Minimal
- Score 5-9: Mild
- Score 10-14: Moderate
- Score 15-21: Severe

### System Prompt Templates

**Base Prompt** (No assessments):
```
You are CalmNest Assistant, a clinically-informed, warm, and supportive mental health companion.
[Standard safety guidelines, crisis protocol, tone style...]
```

**Minimal Severity Addition**:
```
ASSESSMENT CONTEXT:
- Recent PHQ-9 Score: {score}/27 (Minimal depression)
- Recent GAD-7 Score: {score}/21 (Minimal anxiety)

The user is showing minimal symptoms. Focus on:
- Encouraging wellness maintenance
- Preventive mental health strategies
- Positive reinforcement
- Avoid clinical or crisis-oriented language
```

**Mild Severity Addition**:
```
ASSESSMENT CONTEXT:
- Recent PHQ-9 Score: {score}/27 ({severity} depression)
- Recent GAD-7 Score: {score}/21 ({severity} anxiety)

The user is experiencing mild symptoms. Focus on:
- Supportive and practical tone
- Evidence-based self-help techniques (breathing, grounding, journaling)
- Gentle encouragement to monitor symptoms
- Normalize their experience
```

**Moderate Severity Addition**:
```
ASSESSMENT CONTEXT:
- Recent PHQ-9 Score: {score}/27 ({severity} depression)
- Recent GAD-7 Score: {score}/21 ({severity} anxiety)

The user is experiencing moderate symptoms. Focus on:
- Empathetic and validating tone
- Acknowledge the difficulty they're facing
- Recommend seeking professional mental health support
- Provide crisis resources when appropriate
- Balance self-help with professional guidance
```

**Severe Severity Addition**:
```
ASSESSMENT CONTEXT:
- Recent PHQ-9 Score: {score}/27 (Severe depression)
- Recent GAD-7 Score: {score}/21 (Severe anxiety)

CRITICAL: The user is experiencing severe symptoms. You MUST:
- Use compassionate and crisis-aware tone
- STRONGLY recommend immediate professional help
- Provide crisis hotline information prominently:
  * US: 988 (Suicide & Crisis Lifeline)
  * India: AASRA +91-9820466726
- Do NOT provide self-help advice as a substitute for professional care
- Prioritize safety above all else
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After analyzing all acceptance criteria, I identified several areas of redundancy:

1. **Input Validation**: Criteria 1.1, 1.2, 1.4 and 2.1, 2.2, 2.4 all test the same behavior (complete responses required). These can be consolidated into single properties for each assessment type.

2. **Score Range Validation**: Criteria 3.2 and 4.2 are redundant with the score calculation properties (3.1, 4.1) combined with input validation, since valid inputs [0-3] always produce valid output ranges.

3. **Severity Classification**: Criteria 5.1-5.5 and 6.1-6.4 can be consolidated into comprehensive classification properties rather than separate properties for each range.

4. **Assessment Record Structure**: Criteria 7.2-7.5 all test that the stored record contains required fields. These can be combined into a single property about record completeness.

5. **Prompt Conditioning Content**: Criteria 10.2-10.4, 11.2-11.4, 12.2-12.4, 13.2-13.5 all test that prompts contain severity-appropriate content. These can be consolidated into properties about prompt content matching severity level.

6. **Persistence**: Multiple criteria (1.5, 7.1, 7.7) test that records are stored. These can be consolidated into properties about assessment persistence.

The following properties represent the unique, non-redundant validation requirements:


### Property 1: PHQ-9 Complete Response Validation

*For any* PHQ-9 submission, the system SHALL accept it if and only if it contains exactly 9 responses with all values in the range [0, 3].

**Validates: Requirements 1.1, 1.2, 1.3, 1.4**

### Property 2: GAD-7 Complete Response Validation

*For any* GAD-7 submission, the system SHALL accept it if and only if it contains exactly 7 responses with all values in the range [0, 3].

**Validates: Requirements 2.1, 2.2, 2.3, 2.4**

### Property 3: PHQ-9 Score Calculation

*For any* valid PHQ-9 response array, the calculated score SHALL equal the sum of all 9 response values.

**Validates: Requirements 3.1**

### Property 4: GAD-7 Score Calculation

*For any* valid GAD-7 response array, the calculated score SHALL equal the sum of all 7 response values.

**Validates: Requirements 4.1**

### Property 5: PHQ-9 Severity Classification

*For any* PHQ-9 score in the range [0, 27], the severity classification SHALL be:
- "Minimal" for scores 0-4
- "Mild" for scores 5-9
- "Moderate" for scores 10-14
- "Moderately_Severe" for scores 15-19
- "Severe" for scores 20-27

**Validates: Requirements 5.1, 5.2, 5.3, 5.4, 5.5**

### Property 6: GAD-7 Severity Classification

*For any* GAD-7 score in the range [0, 21], the severity classification SHALL be:
- "Minimal" for scores 0-4
- "Mild" for scores 5-9
- "Moderate" for scores 10-14
- "Severe" for scores 15-21

**Validates: Requirements 6.1, 6.2, 6.3, 6.4**

### Property 7: Assessment Record Persistence

*For any* completed assessment (PHQ-9 or GAD-7), the system SHALL persist a record to localStorage containing the assessment type, score, severity level, and timestamp.

**Validates: Requirements 1.5, 2.5, 7.1, 7.2, 7.3, 7.4, 7.5, 7.7**

### Property 8: Assessment Record Completeness

*For any* assessment record retrieved from localStorage, it SHALL contain all required fields: type, score, severity, and timestamp.

**Validates: Requirements 7.2, 7.3, 7.4, 7.5**


### Property 9: Score Display in UI

*For any* calculated assessment score, the system SHALL display that score in the user interface after form submission.

**Validates: Requirements 3.3, 4.3**

### Property 10: Score Persistence

*For any* calculated assessment score, the system SHALL store that exact score value in the assessment record in localStorage.

**Validates: Requirements 3.4, 4.4, 5.6, 6.5**

### Property 11: Most Recent Assessment Retrieval

*For any* set of multiple assessment records of the same type (PHQ-9 or GAD-7), the system SHALL retrieve the record with the most recent timestamp when querying for the latest assessment.

**Validates: Requirements 9.1, 9.2, 16.1, 16.2**

### Property 12: Assessment History Preservation

*For any* existing assessment records in localStorage, adding a new assessment SHALL NOT delete or modify the existing records.

**Validates: Requirements 16.4**

### Property 13: Severity-Based Prompt Injection

*For any* severity level (Minimal, Mild, Moderate, Severe), the conditioned system prompt SHALL contain text indicating that severity level.

**Validates: Requirements 10.1, 11.1, 12.1, 13.1**

### Property 14: Assessment Context in Prompt

*For any* assessment results (PHQ-9 and/or GAD-7), when conditioning the system prompt, the prompt SHALL include both the score and severity level for each available assessment.

**Validates: Requirements 14.1, 14.2, 14.3**

### Property 15: Minimal Severity Prompt Content

*For any* system prompt conditioned with Minimal severity, the prompt SHALL contain keywords related to wellness, prevention, and encouragement, and SHALL NOT contain crisis-related keywords.

**Validates: Requirements 10.2, 10.3, 10.4**

### Property 16: Mild Severity Prompt Content

*For any* system prompt conditioned with Mild severity, the prompt SHALL contain keywords related to self-help techniques, coping strategies, and symptom monitoring.

**Validates: Requirements 11.2, 11.3, 11.4**


### Property 17: Moderate Severity Prompt Content

*For any* system prompt conditioned with Moderate severity, the prompt SHALL contain keywords related to professional help, empathy, validation, and crisis resources.

**Validates: Requirements 12.2, 12.3, 12.4**

### Property 18: Severe Severity Prompt Content

*For any* system prompt conditioned with Severe severity, the prompt SHALL contain keywords strongly recommending immediate professional help, crisis hotline information, and SHALL minimize or exclude self-help advice.

**Validates: Requirements 13.2, 13.3, 13.4, 13.5**

### Property 19: Prompt Conditioning Round-Trip

*For any* severity level and assessment scores, injecting that context into the prompt builder and then parsing the resulting prompt SHALL recover the original severity level and scores.

**Validates: Requirements 17.1**

### Property 20: Valid Severity Level Enforcement

*For any* severity level value passed to the prompt conditioner, if the value is not one of the defined severity levels (Minimal, Mild, Moderate, Moderately_Severe, Severe), the system SHALL reject it or use a default neutral prompt.

**Validates: Requirements 17.3**

### Property 21: Conditioned Prompt in API Call

*For any* chat message sent with assessment context, the resulting API call to Ollama SHALL include the severity-conditioned system prompt.

**Validates: Requirements 17.2**

### Property 22: Automatic Response Generation

*For any* completed assessment, the system SHALL automatically trigger a chatbot response generation using the assessment's severity level and score.

**Validates: Requirements 8.3, 8.4**

### Property 23: Assessment Status Display

*For any* available assessment results (PHQ-9 and/or GAD-7), when the chatbot interface loads, the UI SHALL display the severity level, score, and date for each assessment.

**Validates: Requirements 15.1, 15.2, 15.3**

### Property 24: Most Recent Assessment for Conditioning

*For any* chat interaction, the system SHALL use only the most recent PHQ-9 and GAD-7 assessment results when conditioning the LLM prompt.

**Validates: Requirements 16.3**


## Error Handling

### Client-Side Validation Errors

**Invalid Response Values**
- Error: User submits assessment with values outside [0, 3]
- Handling: Display alert message "Please ensure all responses are valid selections"
- Recovery: Keep form state, allow user to correct

**Incomplete Responses**
- Error: User submits assessment with missing answers
- Handling: Display alert message "Please answer all questions to get your score"
- Recovery: Highlight unanswered questions, keep existing responses

**localStorage Unavailable**
- Error: Browser blocks localStorage access (private mode, quota exceeded)
- Handling: Display warning message "Unable to save assessment results. Your results will not persist."
- Recovery: Continue with in-memory storage for current session only

### Backend API Errors

**Ollama Connection Failure**
- Error: Cannot connect to Ollama API (not running, network issue)
- Handling: Display user-friendly message "Unable to generate response. Please ensure Ollama is running."
- Recovery: Show assessment results without automatic response, allow manual retry

**Ollama Timeout**
- Error: Response generation takes too long (>120 seconds)
- Handling: Display message "Response is taking too long. Try a shorter message or check system resources."
- Recovery: Cancel request, allow user to try again

**Streaming Interruption**
- Error: Connection drops during response streaming
- Handling: Display partial response with indicator "Response incomplete"
- Recovery: Provide retry button

### Data Integrity Errors

**Malformed Assessment Data**
- Error: localStorage contains invalid JSON or missing fields
- Handling: Log warning, skip malformed records
- Recovery: Continue with valid records, display message if no valid data exists

**Invalid Severity Level**
- Error: Severity level in stored data doesn't match defined values
- Handling: Use default neutral prompt, log warning
- Recovery: Continue with default behavior, suggest retaking assessment

**Timestamp Parsing Failure**
- Error: Cannot parse timestamp from stored assessment
- Handling: Use current time as fallback, log warning
- Recovery: Continue with fallback timestamp for sorting


### Safety-Critical Error Handling

**Severe Severity Detection**
- Behavior: When severe symptoms detected, ALWAYS include crisis resources
- Fallback: If prompt conditioning fails, default to including crisis information
- Priority: User safety over feature functionality

**Crisis Keyword Detection**
- Behavior: Existing crisis detection in chatbot remains active regardless of assessment results
- Fallback: Rule-based crisis responses override LLM responses
- Priority: Immediate safety intervention

## Testing Strategy

### Dual Testing Approach

This feature requires both unit tests and property-based tests for comprehensive coverage:

**Unit Tests** focus on:
- Specific examples of score calculations (e.g., all zeros = 0, all threes = 27)
- Edge cases (empty localStorage, malformed data, boundary scores like 4, 5, 14, 15)
- Error conditions (invalid inputs, API failures, timeout scenarios)
- Integration points (localStorage operations, API calls, UI updates)
- Specific severity thresholds (score of 4 vs 5, 14 vs 15, etc.)

**Property-Based Tests** focus on:
- Universal properties across all valid inputs (score calculation for any valid response array)
- Classification correctness for all possible scores
- Persistence round-trips (store then retrieve produces equivalent data)
- Prompt conditioning for all severity combinations
- Assessment retrieval with multiple records

Together, unit tests catch concrete bugs in specific scenarios, while property tests verify general correctness across the input space.

### Property-Based Testing Configuration

**Framework**: Use `hypothesis` for Python backend tests, `fast-check` for JavaScript frontend tests

**Test Iterations**: Minimum 100 iterations per property test to ensure comprehensive input coverage

**Test Tagging**: Each property test MUST include a comment referencing its design property:
```python
# Feature: assessment-based-llm-conditioning, Property 3: PHQ-9 Score Calculation
@given(st.lists(st.integers(min_value=0, max_value=3), min_size=9, max_size=9))
def test_phq9_score_calculation(responses):
    assert calculate_phq9_score(responses) == sum(responses)
```

```javascript
// Feature: assessment-based-llm-conditioning, Property 5: PHQ-9 Severity Classification
fc.assert(
  fc.property(fc.integer(0, 27), (score) => {
    const severity = classifyPHQ9Severity(score);
    // Verify correct classification based on score ranges
  }),
  { numRuns: 100 }
);
```


### Test Coverage by Component

**Assessment Forms (JavaScript)**
- Unit: Specific score calculations, boundary values, form validation
- Property: Score calculation for all valid inputs, classification for all scores
- Integration: localStorage persistence, UI updates, automatic response triggering

**Chatbot Interface (JavaScript)**
- Unit: Assessment status display with specific data, empty state handling
- Property: Latest assessment retrieval with multiple records, context building
- Integration: Message sending with context, streaming response handling

**Backend Prompt Conditioning (Python)**
- Unit: Specific severity prompt templates, default prompt handling
- Property: Prompt conditioning for all severity combinations, round-trip validation
- Integration: Ollama API calls with conditioned prompts, streaming responses

**Score Calculation (JavaScript)**
- Unit: Edge cases (all zeros, all max values, single non-zero)
- Property: Sum correctness for all valid response arrays
- Validation: Output range verification

**Severity Classification (JavaScript)**
- Unit: Boundary values (4, 5, 9, 10, 14, 15, 19, 20, 21, 27)
- Property: Correct classification for all possible scores
- Validation: Exhaustive coverage of all score ranges

### Test Data Generators

**For Property-Based Tests**:

```python
# Python generators for backend tests
from hypothesis import strategies as st

# Valid PHQ-9 responses
phq9_responses = st.lists(st.integers(min_value=0, max_value=3), min_size=9, max_size=9)

# Valid GAD-7 responses
gad7_responses = st.lists(st.integers(min_value=0, max_value=3), min_size=7, max_size=7)

# PHQ-9 scores
phq9_scores = st.integers(min_value=0, max_value=27)

# GAD-7 scores
gad7_scores = st.integers(min_value=0, max_value=21)

# Severity levels
severity_levels = st.sampled_from(["Minimal", "Mild", "Moderate", "Moderately_Severe", "Severe"])

# Assessment records
assessment_records = st.builds(
    dict,
    score=st.integers(min_value=0, max_value=27),
    severity=severity_levels,
    timestamp=st.datetimes(),
    type=st.sampled_from(["PHQ-9", "GAD-7"])
)
```

```javascript
// JavaScript generators for frontend tests
import fc from 'fast-check';

// Valid PHQ-9 responses
const phq9Responses = fc.array(fc.integer(0, 3), { minLength: 9, maxLength: 9 });

// Valid GAD-7 responses
const gad7Responses = fc.array(fc.integer(0, 3), { minLength: 7, maxLength: 7 });

// PHQ-9 scores
const phq9Scores = fc.integer(0, 27);

// GAD-7 scores
const gad7Scores = fc.integer(0, 21);

// Severity levels
const severityLevels = fc.constantFrom("Minimal", "Mild", "Moderate", "Moderately_Severe", "Severe");

// Assessment records
const assessmentRecords = fc.record({
  score: fc.integer(0, 27),
  severity: severityLevels,
  timestamp: fc.date().map(d => d.toISOString()),
  type: fc.constantFrom("PHQ-9", "GAD-7")
});
```


### Critical Test Scenarios

**Scenario 1: First-Time User**
- No existing assessment data
- Complete PHQ-9 assessment
- Verify score calculation, severity classification, persistence
- Verify automatic response generation
- Open chatbot, verify assessment status displayed
- Send message, verify prompt includes assessment context

**Scenario 2: Returning User with History**
- Multiple PHQ-9 and GAD-7 assessments in localStorage
- Complete new assessment
- Verify most recent assessment used for conditioning
- Verify historical data preserved
- Verify chatbot uses latest results

**Scenario 3: Severe Symptoms**
- Complete assessment with high scores (PHQ-9: 25, GAD-7: 20)
- Verify "Severe" classification
- Verify automatic response includes crisis resources
- Verify chatbot prompt strongly emphasizes professional help
- Verify crisis hotline information prominently displayed

**Scenario 4: Severity Progression**
- Complete assessment with minimal symptoms
- Later complete assessment with moderate symptoms
- Verify chatbot tone shifts appropriately
- Verify prompt conditioning reflects current state

**Scenario 5: Offline/Error Conditions**
- Ollama not running
- localStorage quota exceeded
- Network interruption during streaming
- Verify graceful degradation
- Verify user-friendly error messages
- Verify assessment results still displayed

**Scenario 6: Mixed Severity Levels**
- PHQ-9: Minimal (score 3)
- GAD-7: Severe (score 18)
- Verify system uses highest severity (Severe) for conditioning
- Verify both scores included in prompt context

### Manual Testing Checklist

- [ ] Complete PHQ-9 with various score ranges, verify correct severity classification
- [ ] Complete GAD-7 with various score ranges, verify correct severity classification
- [ ] Verify processing indicator appears during automatic response generation
- [ ] Verify automatic response appears on results page
- [ ] Verify assessment status displays correctly in chatbot interface
- [ ] Verify chatbot responses reflect severity-appropriate tone
- [ ] Test with Ollama stopped, verify error handling
- [ ] Test with localStorage disabled, verify warning message
- [ ] Complete multiple assessments, verify latest used for conditioning
- [ ] Verify historical assessments preserved in localStorage
- [ ] Test boundary scores (4, 5, 9, 10, 14, 15, 19, 20, 21, 27)
- [ ] Verify crisis resources appear for severe symptoms
- [ ] Test form validation (incomplete responses, invalid values)
- [ ] Verify UI updates correctly after form submission
- [ ] Test chatbot with no assessment data (default prompt)

