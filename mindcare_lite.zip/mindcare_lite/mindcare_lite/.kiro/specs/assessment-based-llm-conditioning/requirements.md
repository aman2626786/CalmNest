# Requirements Document

## Introduction

This feature enables the mental health chatbot to provide personalized, severity-appropriate responses by integrating PHQ-9 (depression) and GAD-7 (anxiety) assessment results. Users complete standardized mental health assessments, the system calculates scores and determines severity levels, then uses this information to condition the LLM chatbot's tone, content, and recommendations to match the user's mental health state.

## Glossary

- **Assessment_System**: The component responsible for managing PHQ-9 and GAD-7 assessments
- **Score_Calculator**: The component that computes total scores from assessment responses
- **Severity_Classifier**: The component that maps assessment scores to severity levels
- **LLM_Conditioner**: The component that modifies chatbot prompts based on severity levels
- **Chatbot**: The Ollama-based conversational AI interface
- **PHQ-9**: Patient Health Questionnaire-9, a 9-item depression assessment with scores 0-27
- **GAD-7**: Generalized Anxiety Disorder-7, a 7-item anxiety assessment with scores 0-21
- **Severity_Level**: A categorical classification (Minimal, Mild, Moderate, Severe) derived from assessment scores
- **Assessment_Result**: A stored record containing score, severity level, assessment type, and timestamp
- **User_Session**: A persistent user context that maintains assessment history and current severity state

## Requirements

### Requirement 1: Submit PHQ-9 Assessment

**User Story:** As a user, I want to submit my PHQ-9 assessment responses, so that the system can evaluate my depression symptoms.

#### Acceptance Criteria

1. WHEN a user completes all 9 PHQ-9 questions, THE Assessment_System SHALL accept the submission
2. THE Assessment_System SHALL validate that all 9 responses are present before processing
3. THE Assessment_System SHALL validate that each response value is between 0 and 3 inclusive
4. IF any response is missing or invalid, THEN THE Assessment_System SHALL return a validation error message
5. WHEN the submission is valid, THE Assessment_System SHALL store the responses with a timestamp

### Requirement 2: Submit GAD-7 Assessment

**User Story:** As a user, I want to submit my GAD-7 assessment responses, so that the system can evaluate my anxiety symptoms.

#### Acceptance Criteria

1. WHEN a user completes all 7 GAD-7 questions, THE Assessment_System SHALL accept the submission
2. THE Assessment_System SHALL validate that all 7 responses are present before processing
3. THE Assessment_System SHALL validate that each response value is between 0 and 3 inclusive
4. IF any response is missing or invalid, THEN THE Assessment_System SHALL return a validation error message
5. WHEN the submission is valid, THE Assessment_System SHALL store the responses with a timestamp

### Requirement 3: Calculate PHQ-9 Score

**User Story:** As a user, I want the system to calculate my PHQ-9 score, so that I can understand my depression severity level.

#### Acceptance Criteria

1. WHEN PHQ-9 responses are submitted, THE Score_Calculator SHALL sum all 9 response values
2. THE Score_Calculator SHALL produce a total score between 0 and 27 inclusive
3. THE Score_Calculator SHALL return the calculated score to the user interface
4. THE Score_Calculator SHALL store the calculated score with the assessment record

### Requirement 4: Calculate GAD-7 Score

**User Story:** As a user, I want the system to calculate my GAD-7 score, so that I can understand my anxiety severity level.

#### Acceptance Criteria

1. WHEN GAD-7 responses are submitted, THE Score_Calculator SHALL sum all 7 response values
2. THE Score_Calculator SHALL produce a total score between 0 and 21 inclusive
3. THE Score_Calculator SHALL return the calculated score to the user interface
4. THE Score_Calculator SHALL store the calculated score with the assessment record

### Requirement 5: Classify PHQ-9 Severity

**User Story:** As a user, I want the system to classify my depression severity, so that I receive appropriate support and guidance.

#### Acceptance Criteria

1. WHEN the PHQ-9 score is between 0 and 4 inclusive, THE Severity_Classifier SHALL assign severity level "Minimal"
2. WHEN the PHQ-9 score is between 5 and 9 inclusive, THE Severity_Classifier SHALL assign severity level "Mild"
3. WHEN the PHQ-9 score is between 10 and 14 inclusive, THE Severity_Classifier SHALL assign severity level "Moderate"
4. WHEN the PHQ-9 score is between 15 and 19 inclusive, THE Severity_Classifier SHALL assign severity level "Moderately_Severe"
5. WHEN the PHQ-9 score is between 20 and 27 inclusive, THE Severity_Classifier SHALL assign severity level "Severe"
6. THE Severity_Classifier SHALL store the severity level with the assessment record

### Requirement 6: Classify GAD-7 Severity

**User Story:** As a user, I want the system to classify my anxiety severity, so that I receive appropriate support and guidance.

#### Acceptance Criteria

1. WHEN the GAD-7 score is between 0 and 4 inclusive, THE Severity_Classifier SHALL assign severity level "Minimal"
2. WHEN the GAD-7 score is between 5 and 9 inclusive, THE Severity_Classifier SHALL assign severity level "Mild"
3. WHEN the GAD-7 score is between 10 and 14 inclusive, THE Severity_Classifier SHALL assign severity level "Moderate"
4. WHEN the GAD-7 score is between 15 and 21 inclusive, THE Severity_Classifier SHALL assign severity level "Severe"
5. THE Severity_Classifier SHALL store the severity level with the assessment record

### Requirement 7: Persist Assessment Results

**User Story:** As a user, I want my assessment results saved, so that the chatbot can provide personalized responses based on my mental health state.

#### Acceptance Criteria

1. WHEN an assessment is completed, THE Assessment_System SHALL create an Assessment_Result record
2. THE Assessment_Result SHALL include the assessment type (PHQ-9 or GAD-7)
3. THE Assessment_Result SHALL include the total score
4. THE Assessment_Result SHALL include the severity level
5. THE Assessment_Result SHALL include a timestamp
6. THE Assessment_System SHALL associate the Assessment_Result with the User_Session
7. THE Assessment_System SHALL persist the Assessment_Result to storage

### Requirement 8: Generate Automatic Response After Assessment

**User Story:** As a user, I want to receive an immediate personalized chatbot response after completing an assessment, so that I get instant feedback and support based on my results.

#### Acceptance Criteria

1. WHEN an assessment form is submitted, THE Assessment_System SHALL display a processing indicator to the user
2. WHILE the assessment is being processed, THE Assessment_System SHALL show a loading animation with appropriate messaging
3. WHEN the severity level is determined, THE Chatbot SHALL automatically generate a personalized response based on the severity level
4. THE Chatbot SHALL use the LLM_Conditioner to apply severity-appropriate tone and content to the automatic response
5. WHEN the automatic response is generated, THE Assessment_System SHALL hide the processing indicator
6. WHEN the automatic response is generated, THE Chatbot SHALL display the personalized message to the user
7. IF response generation fails, THEN THE Assessment_System SHALL display the assessment results without the automatic response

### Requirement 9: Retrieve Latest Assessment Results

**User Story:** As a system, I need to retrieve the user's most recent assessment results, so that the chatbot can be conditioned appropriately.

#### Acceptance Criteria

1. WHEN the Chatbot initializes a conversation, THE Assessment_System SHALL retrieve the most recent PHQ-9 result for the User_Session
2. WHEN the Chatbot initializes a conversation, THE Assessment_System SHALL retrieve the most recent GAD-7 result for the User_Session
3. IF no assessment results exist, THEN THE Assessment_System SHALL return null values
4. THE Assessment_System SHALL return both the severity level and score for each assessment type

### Requirement 10: Condition LLM Prompts for Minimal Severity

**User Story:** As a user with minimal symptoms, I want the chatbot to provide supportive and preventive guidance, so that I can maintain my mental wellness.

#### Acceptance Criteria

1. WHEN both PHQ-9 and GAD-7 severity levels are "Minimal", THE LLM_Conditioner SHALL inject a system prompt indicating minimal symptom severity
2. THE LLM_Conditioner SHALL configure the Chatbot to use an encouraging and wellness-focused tone
3. THE LLM_Conditioner SHALL configure the Chatbot to emphasize preventive mental health strategies
4. THE LLM_Conditioner SHALL configure the Chatbot to avoid clinical or crisis-oriented language

### Requirement 11: Condition LLM Prompts for Mild Severity

**User Story:** As a user with mild symptoms, I want the chatbot to provide practical coping strategies, so that I can manage my symptoms effectively.

#### Acceptance Criteria

1. WHEN either PHQ-9 or GAD-7 severity level is "Mild", THE LLM_Conditioner SHALL inject a system prompt indicating mild symptom severity
2. THE LLM_Conditioner SHALL configure the Chatbot to use a supportive and practical tone
3. THE LLM_Conditioner SHALL configure the Chatbot to suggest evidence-based self-help techniques
4. THE LLM_Conditioner SHALL configure the Chatbot to gently recommend monitoring symptoms

### Requirement 12: Condition LLM Prompts for Moderate Severity

**User Story:** As a user with moderate symptoms, I want the chatbot to provide empathetic support and professional guidance, so that I can access appropriate care.

#### Acceptance Criteria

1. WHEN either PHQ-9 or GAD-7 severity level is "Moderate" or "Moderately_Severe", THE LLM_Conditioner SHALL inject a system prompt indicating moderate symptom severity
2. THE LLM_Conditioner SHALL configure the Chatbot to use an empathetic and validating tone
3. THE LLM_Conditioner SHALL configure the Chatbot to recommend seeking professional mental health support
4. THE LLM_Conditioner SHALL configure the Chatbot to provide crisis resources when appropriate

### Requirement 13: Condition LLM Prompts for Severe Severity

**User Story:** As a user with severe symptoms, I want the chatbot to prioritize my safety and strongly encourage professional help, so that I can receive urgent care.

#### Acceptance Criteria

1. WHEN either PHQ-9 or GAD-7 severity level is "Severe", THE LLM_Conditioner SHALL inject a system prompt indicating severe symptom severity
2. THE LLM_Conditioner SHALL configure the Chatbot to use a compassionate and crisis-aware tone
3. THE LLM_Conditioner SHALL configure the Chatbot to strongly recommend immediate professional help
4. THE LLM_Conditioner SHALL configure the Chatbot to provide crisis hotline information prominently
5. THE LLM_Conditioner SHALL configure the Chatbot to avoid providing self-help advice as a substitute for professional care

### Requirement 14: Include Assessment Context in Chatbot Prompts

**User Story:** As a user, I want the chatbot to be aware of my specific assessment scores, so that it can provide contextually relevant responses.

#### Acceptance Criteria

1. WHEN assessment results exist, THE LLM_Conditioner SHALL include the PHQ-9 score in the system prompt
2. WHEN assessment results exist, THE LLM_Conditioner SHALL include the GAD-7 score in the system prompt
3. WHEN assessment results exist, THE LLM_Conditioner SHALL include both severity levels in the system prompt
4. THE LLM_Conditioner SHALL format the assessment context in a way that the LLM can interpret
5. IF no assessment results exist, THEN THE LLM_Conditioner SHALL use a default neutral system prompt

### Requirement 15: Display Assessment Status in Chatbot Interface

**User Story:** As a user, I want to see my current assessment status in the chatbot interface, so that I know the chatbot is aware of my mental health state.

#### Acceptance Criteria

1. WHEN a user opens the Chatbot interface, THE Chatbot SHALL display the most recent PHQ-9 severity level if available
2. WHEN a user opens the Chatbot interface, THE Chatbot SHALL display the most recent GAD-7 severity level if available
3. WHEN a user opens the Chatbot interface, THE Chatbot SHALL display the date of the most recent assessments
4. IF no assessments exist, THEN THE Chatbot SHALL display a message encouraging the user to complete assessments
5. THE Chatbot SHALL provide links to the PHQ-9 and GAD-7 assessment pages

### Requirement 16: Handle Multiple Assessment History

**User Story:** As a user who takes assessments multiple times, I want the system to use my most recent results, so that the chatbot reflects my current mental health state.

#### Acceptance Criteria

1. WHEN multiple PHQ-9 assessments exist for a User_Session, THE Assessment_System SHALL identify the most recent by timestamp
2. WHEN multiple GAD-7 assessments exist for a User_Session, THE Assessment_System SHALL identify the most recent by timestamp
3. THE LLM_Conditioner SHALL use only the most recent assessment results for prompt conditioning
4. THE Assessment_System SHALL maintain historical assessment records for potential future analysis

### Requirement 17: Validate Severity-Based Prompt Injection

**User Story:** As a system administrator, I want to ensure that severity-based prompts are correctly injected, so that users receive appropriate chatbot responses.

#### Acceptance Criteria

1. FOR ALL severity levels, injecting severity context then retrieving the system prompt SHALL produce a prompt containing the severity information (round-trip property)
2. WHEN the LLM_Conditioner injects a severity-based prompt, THE Chatbot SHALL include the prompt in the next API call to Ollama
3. THE LLM_Conditioner SHALL validate that the severity level is one of the defined values before injection
4. IF an invalid severity level is provided, THEN THE LLM_Conditioner SHALL use the default neutral prompt
