# Implementation Plan: Complete Analysis Workflow

## Overview

This implementation plan breaks down the Complete Analysis Workflow feature into discrete coding tasks. The workflow orchestrates multiple mental health assessments (GAD-7, PHQ-9, emotion detection, lifestyle questionnaire) into a unified experience with comprehensive reporting and chatbot integration.

The implementation follows a bottom-up approach: core infrastructure first, then individual components, followed by integration and UI polish.

## Tasks

- [x] 1. Set up project infrastructure and data models
  - Create `data/sessions/` directory for storing session data
  - Create `workflow_orchestrator.py` module with core classes
  - Create `data_store.py` module with persistence functions
  - Define data models (WorkflowSession, GAD7Result, PHQ9Result, EmotionResult, LifestyleData)
  - Set up error handling classes (CameraAccessError, DataStoreError)
  - _Requirements: 1.6, 3.5, 3.6, 9.2_

- [ ]* 1.1 Write property test for session state persistence
  - **Property 1: Session State Persistence**
  - **Validates: Requirements 1.6, 1.7**
  - Test that saving and loading session state returns equivalent data

- [x] 2. Implement workflow orchestrator core logic
  - [x] 2.1 Implement WorkflowOrchestrator class
    - Implement `__init__`, `get_current_step`, `get_next_step` methods
    - Implement `advance_step`, `get_progress`, `is_complete` methods
    - Define WORKFLOW_STEPS constant: ['gad7', 'phq9', 'emotion', 'lifestyle', 'report']
    - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5, 1.6_
  
  - [x] 2.2 Implement workflow management functions
    - Implement `start_workflow()` to create new session with UUID
    - Implement `get_workflow_state(session_id)` to retrieve state from session
    - Implement `save_assessment_data(session_id, assessment_type, data)` to persist data
    - _Requirements: 1.6, 1.7, 3.5_
  
  - [ ]* 2.3 Write property test for workflow step advancement
    - **Property 3: Workflow Step Advancement**
    - **Validates: Requirements 1.6, 6.4**
    - Test that advancing from step N results in step N+1

- [x] 3. Implement data persistence layer
  - [x] 3.1 Implement data store functions
    - Implement `save_session_data(session_id, data)` with JSON file writing
    - Implement `load_session_data(session_id)` with JSON file reading
    - Implement `update_assessment(session_id, assessment_type, assessment_data)`
    - Implement `get_assessment(session_id, assessment_type)`
    - Add file locking for concurrent access safety
    - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5, 3.6_
  
  - [ ]* 3.2 Write property test for assessment data round-trip
    - **Property 2: Assessment Data Round-Trip**
    - **Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**
    - Test that saving and loading assessment data returns equivalent data
  
  - [ ]* 3.3 Write property test for session data isolation
    - **Property 9: Session Data Isolation**
    - **Validates: Requirements 3.5, 9.1**
    - Test that data from one session ID cannot be retrieved with another session ID

- [x] 4. Implement assessment score calculation and severity classification
  - [x] 4.1 Implement score calculation functions
    - Implement `calculate_assessment_score(assessment_type, responses)` for GAD-7 and PHQ-9
    - Sum all response values to get total score
    - _Requirements: 7.1, 7.3_
  
  - [x] 4.2 Implement severity classification functions
    - Implement `calculate_severity(assessment_type, score)` for GAD-7 and PHQ-9
    - GAD-7 ranges: 0-4 (minimal), 5-9 (mild), 10-14 (moderate), 15-21 (severe)
    - PHQ-9 ranges: 0-4 (minimal), 5-9 (mild), 10-14 (moderate), 15-19 (moderately_severe), 20-27 (severe)
    - _Requirements: 7.2, 7.4_
  
  - [ ]* 4.3 Write property test for score calculation correctness
    - **Property 4: Score Calculation Correctness**
    - **Validates: Requirements 7.1, 7.3**
    - Test that calculated score equals sum of responses
  
  - [ ]* 4.4 Write property test for severity classification correctness
    - **Property 5: Severity Classification Correctness**
    - **Validates: Requirements 7.2, 7.4**
    - Test that severity levels match defined ranges for all scores

- [ ] 5. Checkpoint - Ensure core infrastructure tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 6. Implement Flask routes for workflow initiation and GAD-7
  - [x] 6.1 Create workflow start route
    - Implement `/complete-analysis/start` route
    - Call `start_workflow()` to create session
    - Store session_id in Flask session
    - Redirect to `/complete-analysis/gad7`
    - _Requirements: 1.1, 1.6_
  
  - [x] 6.2 Create GAD-7 workflow routes
    - Implement `/complete-analysis/gad7` GET route
    - Render existing GAD-7 template with workflow context (progress indicator)
    - Implement `/complete-analysis/gad7/submit` POST route
    - Calculate score and severity, save to data store
    - Advance workflow step, redirect to PHQ-9
    - _Requirements: 1.1, 1.2, 7.1, 7.2, 3.1_
  
  - [ ]* 6.3 Write unit tests for GAD-7 workflow routes
    - Test workflow starts with GAD-7
    - Test GAD-7 submission advances to PHQ-9
    - Test score calculation and severity classification
    - _Requirements: 1.1, 1.2, 7.1, 7.2_

- [x] 7. Implement Flask routes for PHQ-9 and emotion detection
  - [x] 7.1 Create PHQ-9 workflow routes
    - Implement `/complete-analysis/phq9` GET route
    - Render existing PHQ-9 template with workflow context
    - Implement `/complete-analysis/phq9/submit` POST route
    - Calculate score and severity, save to data store
    - Advance workflow step, redirect to emotion detection
    - _Requirements: 1.2, 1.3, 7.3, 7.4, 3.2_
  
  - [x] 7.2 Create emotion detection workflow routes
    - Implement `/complete-analysis/emotion` GET route
    - Render existing emotion detection template with workflow context
    - Implement `/complete-analysis/emotion/submit` POST route
    - Save emotion data to data store
    - Advance workflow step, redirect to lifestyle questionnaire
    - Add error handling for camera access failures (retry/skip options)
    - _Requirements: 1.3, 1.4, 3.3, 8.1_
  
  - [ ]* 7.3 Write unit tests for PHQ-9 and emotion routes
    - Test PHQ-9 submission advances to emotion detection
    - Test emotion detection submission advances to lifestyle
    - Test camera access error handling
    - _Requirements: 1.2, 1.3, 1.4, 8.1_

- [x] 8. Implement lifestyle questionnaire
  - [x] 8.1 Create lifestyle questionnaire template
    - Create `templates/workflow_lifestyle.html` extending `base.html`
    - Include workflow progress indicator component
    - Add 8 textarea fields for Hinglish questions:
      - "Hobbies kya hai?"
      - "Recently kya aur kesa kha rahe ho?"
      - "Daily life kesi hai?"
      - "Sleeping time kitna follow kar rahe ho?"
      - "Meditation kar rahe ho ya nahi?"
      - "Exercise kar rahe ho?"
      - "Kya karke good feel karte ho?"
      - "Konsi cheezein happy feel karwati hain?"
    - Add form validation (all fields required)
    - Style with Tailwind CSS matching existing design system
    - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8_
  
  - [x] 8.2 Create lifestyle questionnaire routes
    - Implement `/complete-analysis/lifestyle` GET route
    - Render lifestyle questionnaire template with workflow context
    - Implement `/complete-analysis/lifestyle/submit` POST route
    - Validate all 8 fields are present
    - Save lifestyle data to data store
    - Advance workflow step, redirect to report
    - _Requirements: 2.9, 3.4, 1.4, 1.5_
  
  - [ ]* 8.3 Write property test for lifestyle form completeness
    - **Property 10: Lifestyle Form Completeness**
    - **Validates: Requirements 2.1-2.9**
    - Test that all 8 question responses are persisted and retrievable
  
  - [ ]* 8.4 Write unit tests for lifestyle questionnaire
    - Test all 8 fields are present in template
    - Test form validation
    - Test submission advances to report
    - _Requirements: 2.1-2.9, 1.5_

- [ ] 9. Checkpoint - Ensure workflow routes tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [x] 10. Implement analysis report generation
  - [x] 10.1 Create analysis report template
    - Create `templates/workflow_report.html` extending `base.html`
    - Display GAD-7 score and severity with color-coded badge
    - Display PHQ-9 score and severity with color-coded badge
    - Display emotion detection results
    - Display all 8 lifestyle questionnaire responses in organized sections
    - Add "Concern with Jaya" button (prominent CTA)
    - Style with Tailwind CSS and glass-card design
    - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.8, 5.1_
  
  - [x] 10.2 Create analysis report routes
    - Implement `/complete-analysis/report` GET route
    - Retrieve session_id from Flask session
    - Load all assessment data from data store
    - Render report template with complete data
    - Implement `/complete-analysis/report/<session_id>` GET route for viewing specific reports
    - Add error handling for missing session data
    - _Requirements: 4.7, 8.3_
  
  - [ ]* 10.3 Write property test for report data completeness
    - **Property 6: Report Data Completeness**
    - **Validates: Requirements 4.1-4.7**
    - Test that report contains all assessment data elements
  
  - [ ]* 10.4 Write unit tests for analysis report
    - Test report displays all assessment data
    - Test "Concern with Jaya" button is present
    - Test error handling for missing session
    - _Requirements: 4.1-4.8, 5.1, 8.3_

- [x] 11. Implement chatbot context integration
  - [x] 11.1 Create context loading function
    - Implement `load_assessment_context(session_id)` in app.py
    - Load all assessment data from data store
    - Format context string with GAD-7, PHQ-9, emotion, and lifestyle data
    - Return formatted context for chatbot prompt
    - _Requirements: 5.4, 5.5, 5.6, 5.7_
  
  - [x] 11.2 Create chatbot route with context
    - Implement `/chatbot/with-context/<session_id>` GET route
    - Load assessment context using session_id
    - Render chatbot template with pre-loaded context
    - Add error handling for context loading failures
    - _Requirements: 5.2, 5.3, 8.4_
  
  - [x] 11.3 Modify chat-stream endpoint to accept context
    - Update `/chat-stream` POST endpoint to accept optional session_id
    - If session_id provided, prepend assessment context to Ollama prompt
    - Ensure context is included in system message for personalization
    - _Requirements: 5.8_
  
  - [ ]* 11.4 Write property test for chatbot context completeness
    - **Property 7: Chatbot Context Completeness**
    - **Validates: Requirements 5.4, 5.5, 5.6, 5.7**
    - Test that loaded context includes all completed assessment data
  
  - [ ]* 11.5 Write unit tests for chatbot integration
    - Test context loading function
    - Test chatbot route with context
    - Test chat-stream endpoint with session_id
    - Test error handling for context loading failures
    - _Requirements: 5.2, 5.3, 5.4, 5.5, 5.6, 5.7, 5.8, 8.4_

- [x] 12. Implement workflow progress indicator component
  - [x] 12.1 Create progress indicator template component
    - Create `templates/components/workflow_progress.html`
    - Display current step number and total steps
    - Display percentage completion
    - Display visual progress bar with Tailwind CSS
    - Display step names with highlighting for completed steps
    - _Requirements: 6.1, 6.2, 6.3_
  
  - [x] 12.2 Integrate progress indicator into workflow templates
    - Include progress indicator in GAD-7 workflow template
    - Include progress indicator in PHQ-9 workflow template
    - Include progress indicator in emotion detection workflow template
    - Include progress indicator in lifestyle questionnaire template
    - Pass progress data from routes to templates
    - _Requirements: 6.1, 6.2, 6.3, 6.4_
  
  - [ ]* 12.3 Write property test for progress indicator accuracy
    - **Property 8: Progress Indicator Accuracy**
    - **Validates: Requirements 6.1, 6.2, 6.3**
    - Test that progress indicator displays correct step, total, and percentage
  
  - [ ]* 12.4 Write unit tests for progress indicator
    - Test progress indicator component renders correctly
    - Test progress updates after each step
    - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 13. Implement home page integration
  - [x] 13.1 Add "Complete Analysis" button to home page
    - Modify `templates/index.html` to add new CTA button
    - Button text: "Complete Analysis" or "Start Complete Assessment"
    - Link to `/complete-analysis/start`
    - Style with Tailwind CSS matching existing buttons
    - Position prominently on home page (e.g., in hero section or main navigation)
    - _Requirements: 1.1_
  
  - [ ]* 13.2 Write unit tests for home page integration
    - Test "Complete Analysis" button is present
    - Test button links to correct route
    - _Requirements: 1.1_

- [ ] 14. Implement error handling and recovery mechanisms
  - [ ] 14.1 Add data persistence error handling
    - Wrap all `save_session_data` calls with try-except
    - Display user-friendly error messages
    - Provide retry button for transient failures
    - Log errors for debugging
    - _Requirements: 3.7, 8.2_
  
  - [ ] 14.2 Add session retrieval error handling
    - Handle missing session data gracefully
    - Display "Session not found" message with option to start new assessment
    - Redirect to home page if session is invalid
    - _Requirements: 8.3_
  
  - [x] 14.3 Add camera access error handling
    - Catch camera access exceptions in emotion detection route
    - Display error message with retry and skip options
    - Allow workflow to continue without emotion data if skipped
    - _Requirements: 8.1_
  
  - [ ] 14.4 Add chatbot context error handling
    - Handle context loading failures gracefully
    - Display error message with retry option
    - Allow chatbot use without context as fallback
    - _Requirements: 8.4_
  
  - [ ]* 14.5 Write unit tests for error handling
    - Test data persistence error handling
    - Test session retrieval error handling
    - Test camera access error handling
    - Test chatbot context error handling
    - _Requirements: 8.1, 8.2, 8.3, 8.4_

- [ ] 15. Checkpoint - Ensure all integration tests pass
  - Ensure all tests pass, ask the user if questions arise.

- [ ] 16. Implement data privacy and security measures
  - [x] 16.1 Set up secure data storage
    - Ensure `data/sessions/` directory has appropriate permissions (read/write for app only)
    - Add `.gitignore` entry for `data/sessions/` to prevent committing user data
    - Implement file naming convention using session UUID only (no PII)
    - _Requirements: 9.1, 9.2_
  
  - [ ] 16.2 Implement secure data transmission to chatbot
    - Ensure session_id is passed securely (no URL exposure of sensitive data)
    - Use POST method for chat-stream endpoint with session_id in request body
    - Validate session_id format before loading data
    - _Requirements: 9.3_
  
  - [ ]* 16.3 Write unit tests for data privacy measures
    - Test session data isolation
    - Test file permissions
    - Test secure data transmission
    - _Requirements: 9.1, 9.2, 9.3, 9.4_

- [ ] 17. Final integration and polish
  - [x] 17.1 Wire all components together
    - Verify all routes are registered in app.py
    - Verify all templates extend base.html correctly
    - Verify all static assets (CSS, JS) are loaded
    - Test complete workflow end-to-end manually
    - _Requirements: All_
  
  - [x] 17.2 Add session state preservation
    - Implement session timeout handling (24 hours)
    - Allow users to resume workflow from last completed step
    - Store workflow state in Flask session and file system
    - _Requirements: 1.7_
  
  - [ ]* 17.3 Write integration test for complete workflow
    - Test end-to-end workflow from start to chatbot
    - Test all assessments are saved correctly
    - Test report displays all data
    - Test chatbot receives complete context
    - _Requirements: All_

- [ ] 18. Final checkpoint - Ensure all tests pass
  - Ensure all tests pass, ask the user if questions arise.

## Notes

- Tasks marked with `*` are optional and can be skipped for faster MVP
- Each task references specific requirements for traceability
- Property tests validate universal correctness properties using hypothesis library
- Unit tests validate specific examples, edge cases, and error conditions
- Integration tests validate end-to-end workflows
- Checkpoints ensure incremental validation and provide opportunities for user feedback
- All code should follow Flask best practices and match existing CalmNest design patterns
- Templates should use Tailwind CSS and maintain visual consistency with existing pages
