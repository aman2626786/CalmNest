# Design Document: Complete Analysis Workflow

## Overview

The Complete Analysis Workflow feature extends CalmNest's existing mental health assessment capabilities by orchestrating multiple assessments into a unified, sequential workflow. Users will progress through GAD-7, PHQ-9, emotion detection, and a custom lifestyle questionnaire, culminating in a comprehensive analysis report that can be shared with the Jaya chatbot for personalized support.

### Key Design Goals

- Seamless integration with existing assessment pages (GAD-7, PHQ-9, emotion detection)
- Minimal code duplication by reusing existing components
- File-based persistence for reliability and simplicity
- Session-based workflow state management
- Clear progress indication throughout the workflow
- Graceful error handling and recovery

### Technology Stack

- **Backend**: Flask with session management
- **Frontend**: Jinja2 templates with Tailwind CSS (matching existing design system)
- **Data Storage**: JSON files in a dedicated `data/` directory
- **State Management**: Flask sessions with server-side storage
- **UI Components**: Lucide icons, existing glass-card styling

## Architecture

### System Components

```
┌─────────────────────────────────────────────────────────────┐
│                         User Interface                       │
├─────────────────────────────────────────────────────────────┤
│  Home Page  │  Workflow Pages  │  Report Page  │  Chatbot   │
└──────┬──────────────┬───────────────┬──────────────┬────────┘
       │              │               │              │
       ▼              ▼               ▼              ▼
┌─────────────────────────────────────────────────────────────┐
│                    Flask Application Layer                   │
├─────────────────────────────────────────────────────────────┤
│  Workflow      │  Session       │  Data          │  Chatbot │
│  Orchestrator  │  Manager       │  Persistence   │  Context │
└──────┬──────────────┬───────────────┬──────────────┬────────┘
       │              │               │              │
       ▼              ▼               ▼              ▼
┌─────────────────────────────────────────────────────────────┐
│                      Data Layer                              │
├─────────────────────────────────────────────────────────────┤
│  Flask Session  │  JSON Files (data/sessions/)              │
└─────────────────────────────────────────────────────────────┘
```

### Workflow State Machine

```
┌──────────┐
│   Home   │
│   Page   │
└────┬─────┘
     │ Click "Complete Analysis"
     ▼
┌──────────┐     ┌──────────┐     ┌──────────┐     ┌──────────┐
│  GAD-7   │────▶│  PHQ-9   │────▶│ Emotion  │────▶│Lifestyle │
│  Test    │     │  Test    │     │ Analysis │     │   Form   │
└──────────┘     └──────────┘     └──────────┘     └──────────┘
     │                │                 │                 │
     │                │                 │                 │
     └────────────────┴─────────────────┴─────────────────┘
                            │
                            ▼
                    ┌──────────────┐
                    │   Analysis   │
                    │    Report    │
                    └──────┬───────┘
                           │
                           ▼
                    ┌──────────────┐
                    │   Chatbot    │
                    │  (Optional)  │
                    └──────────────┘
```

### Data Flow

1. **Workflow Initiation**: User clicks "Complete Analysis" → Session created with unique ID
2. **Assessment Completion**: Each assessment saves data → Session state updated → Next step triggered
3. **Data Persistence**: Assessment results → JSON file (keyed by session ID)
4. **Report Generation**: Retrieve all session data → Render comprehensive report
5. **Chatbot Integration**: Pass session ID → Chatbot loads context from file

## Components and Interfaces

### 1. Workflow Orchestrator Module

**File**: `workflow_orchestrator.py`

**Purpose**: Manages workflow state transitions and coordinates assessment flow.

**Key Classes**:

```python
class WorkflowOrchestrator:
    """Manages the complete analysis workflow state and transitions."""
    
    WORKFLOW_STEPS = [
        'gad7',
        'phq9', 
        'emotion',
        'lifestyle',
        'report'
    ]
    
    def __init__(self, session_id: str):
        """Initialize orchestrator with session ID."""
        
    def get_current_step(self) -> str:
        """Returns current workflow step name."""
        
    def get_next_step(self) -> Optional[str]:
        """Returns next workflow step or None if complete."""
        
    def advance_step(self) -> bool:
        """Advances to next step, returns success status."""
        
    def get_progress(self) -> dict:
        """Returns progress info: {current: int, total: int, percent: float}."""
        
    def is_complete(self) -> bool:
        """Returns True if workflow is complete."""
```

**Key Functions**:

```python
def start_workflow() -> str:
    """Creates new workflow session, returns session_id."""
    
def get_workflow_state(session_id: str) -> dict:
    """Retrieves current workflow state from session."""
    
def save_assessment_data(session_id: str, assessment_type: str, data: dict) -> bool:
    """Saves assessment data to persistent storage."""
```

### 2. Data Persistence Module

**File**: `data_store.py`

**Purpose**: Handles reading/writing assessment data to JSON files.

**Key Functions**:

```python
def save_session_data(session_id: str, data: dict) -> bool:
    """Saves complete session data to JSON file."""
    
def load_session_data(session_id: str) -> Optional[dict]:
    """Loads session data from JSON file."""
    
def update_assessment(session_id: str, assessment_type: str, assessment_data: dict) -> bool:
    """Updates specific assessment within session data."""
    
def get_assessment(session_id: str, assessment_type: str) -> Optional[dict]:
    """Retrieves specific assessment data."""
```

**Data Structure**:

```json
{
  "session_id": "uuid-string",
  "created_at": "2024-01-15T10:30:00Z",
  "updated_at": "2024-01-15T10:45:00Z",
  "workflow_state": {
    "current_step": "lifestyle",
    "completed_steps": ["gad7", "phq9", "emotion"],
    "is_complete": false
  },
  "assessments": {
    "gad7": {
      "score": 12,
      "severity": "moderate",
      "completed_at": "2024-01-15T10:32:00Z"
    },
    "phq9": {
      "score": 15,
      "severity": "moderately_severe",
      "completed_at": "2024-01-15T10:35:00Z"
    },
    "emotion": {
      "detected_emotion": "sad",
      "confidence": 0.85,
      "mood_data": {...},
      "completed_at": "2024-01-15T10:40:00Z"
    },
    "lifestyle": {
      "hobbies": "Reading and painting",
      "eating_habits": "Irregular, mostly fast food",
      "daily_life": "Stressful, work pressure",
      "sleep_schedule": "5-6 hours, irregular",
      "meditation": "No",
      "exercise": "Rarely",
      "feel_good_activities": "Listening to music",
      "happiness_triggers": "Spending time with family",
      "completed_at": "2024-01-15T10:45:00Z"
    }
  }
}
```

### 3. Flask Routes

**File**: `app.py` (additions)

**New Routes**:

```python
@app.route("/complete-analysis/start")
def start_complete_analysis():
    """Initiates workflow, redirects to first step (GAD-7)."""
    
@app.route("/complete-analysis/gad7")
def workflow_gad7():
    """GAD-7 assessment within workflow context."""
    
@app.route("/complete-analysis/gad7/submit", methods=["POST"])
def submit_workflow_gad7():
    """Handles GAD-7 submission, advances workflow."""
    
@app.route("/complete-analysis/phq9")
def workflow_phq9():
    """PHQ-9 assessment within workflow context."""
    
@app.route("/complete-analysis/phq9/submit", methods=["POST"])
def submit_workflow_phq9():
    """Handles PHQ-9 submission, advances workflow."""
    
@app.route("/complete-analysis/emotion")
def workflow_emotion():
    """Emotion detection within workflow context."""
    
@app.route("/complete-analysis/emotion/submit", methods=["POST"])
def submit_workflow_emotion():
    """Handles emotion data submission, advances workflow."""
    
@app.route("/complete-analysis/lifestyle")
def workflow_lifestyle():
    """Lifestyle questionnaire page."""
    
@app.route("/complete-analysis/lifestyle/submit", methods=["POST"])
def submit_workflow_lifestyle():
    """Handles lifestyle form submission, advances to report."""
    
@app.route("/complete-analysis/report")
def workflow_report():
    """Displays comprehensive analysis report."""
    
@app.route("/complete-analysis/report/<session_id>")
def view_report(session_id):
    """View a specific report by session ID."""
    
@app.route("/chatbot/with-context/<session_id>")
def chatbot_with_context(session_id):
    """Opens chatbot with pre-loaded assessment context."""
```

### 4. UI Templates

#### Progress Indicator Component

**File**: `templates/components/workflow_progress.html`

```html
<!-- Reusable progress indicator -->
<div class="workflow-progress mb-8">
    <div class="flex justify-between items-center mb-2">
        <span class="text-sm font-medium text-gray-700">
            Step {{ current_step }} of {{ total_steps }}
        </span>
        <span class="text-sm text-gray-500">{{ progress_percent }}% Complete</span>
    </div>
    <div class="w-full bg-gray-200 rounded-full h-2">
        <div class="bg-blue-600 h-2 rounded-full transition-all duration-300" 
             style="width: {{ progress_percent }}%"></div>
    </div>
    <div class="flex justify-between mt-4 text-xs text-gray-500">
        <span class="{{ 'text-blue-600 font-medium' if current_step >= 1 }}">GAD-7</span>
        <span class="{{ 'text-blue-600 font-medium' if current_step >= 2 }}">PHQ-9</span>
        <span class="{{ 'text-blue-600 font-medium' if current_step >= 3 }}">Emotion</span>
        <span class="{{ 'text-blue-600 font-medium' if current_step >= 4 }}">Lifestyle</span>
        <span class="{{ 'text-blue-600 font-medium' if current_step >= 5 }}">Report</span>
    </div>
</div>
```

#### Lifestyle Questionnaire Template

**File**: `templates/workflow_lifestyle.html`

- Extends `base.html`
- Includes progress indicator
- 8 text area fields for Hinglish questions
- Form validation
- Submit button advances to report

#### Analysis Report Template

**File**: `templates/workflow_report.html`

- Extends `base.html`
- Displays all assessment results in organized sections
- Visual severity indicators (color-coded badges)
- Lifestyle responses in readable format
- "Concern with Jaya" button (prominent CTA)
- Option to download/print report

### 5. Chatbot Context Integration

**Modifications to**: `app.py` chatbot functions

**Context Loading**:

```python
def load_assessment_context(session_id: str) -> str:
    """Loads assessment data and formats for chatbot context."""
    data = load_session_data(session_id)
    
    context = f"""
    User Assessment Context:
    
    Anxiety (GAD-7): Score {data['assessments']['gad7']['score']} - {data['assessments']['gad7']['severity']}
    Depression (PHQ-9): Score {data['assessments']['phq9']['score']} - {data['assessments']['phq9']['severity']}
    Emotion: {data['assessments']['emotion']['detected_emotion']}
    
    Lifestyle Information:
    - Hobbies: {data['assessments']['lifestyle']['hobbies']}
    - Eating: {data['assessments']['lifestyle']['eating_habits']}
    - Daily Life: {data['assessments']['lifestyle']['daily_life']}
    - Sleep: {data['assessments']['lifestyle']['sleep_schedule']}
    - Meditation: {data['assessments']['lifestyle']['meditation']}
    - Exercise: {data['assessments']['lifestyle']['exercise']}
    - Feel Good: {data['assessments']['lifestyle']['feel_good_activities']}
    - Happiness: {data['assessments']['lifestyle']['happiness_triggers']}
    """
    
    return context
```

**Modified Chat Endpoint**:

```python
@app.route("/chat-stream", methods=["POST"])
def chat_stream():
    """Enhanced to accept optional session_id for context."""
    data = request.get_json()
    user_message = data.get("message", "")
    session_id = data.get("session_id")  # Optional
    
    # If session_id provided, prepend context to prompt
    if session_id:
        assessment_context = load_assessment_context(session_id)
        # Include context in Ollama prompt
    
    # ... rest of existing logic
```

## Data Models

### Session State Model

```python
@dataclass
class WorkflowSession:
    session_id: str
    created_at: datetime
    updated_at: datetime
    current_step: str
    completed_steps: List[str]
    is_complete: bool
```

### Assessment Models

```python
@dataclass
class GAD7Result:
    score: int
    severity: str  # 'minimal', 'mild', 'moderate', 'severe'
    completed_at: datetime

@dataclass
class PHQ9Result:
    score: int
    severity: str  # 'minimal', 'mild', 'moderate', 'moderately_severe', 'severe'
    completed_at: datetime

@dataclass
class EmotionResult:
    detected_emotion: str
    confidence: float
    mood_data: dict
    completed_at: datetime

@dataclass
class LifestyleData:
    hobbies: str
    eating_habits: str
    daily_life: str
    sleep_schedule: str
    meditation: str
    exercise: str
    feel_good_activities: str
    happiness_triggers: str
    completed_at: datetime
```

### Complete Session Model

```python
@dataclass
class CompleteAnalysisSession:
    session_id: str
    created_at: datetime
    updated_at: datetime
    workflow_state: WorkflowSession
    gad7: Optional[GAD7Result]
    phq9: Optional[PHQ9Result]
    emotion: Optional[EmotionResult]
    lifestyle: Optional[LifestyleData]
```


## Correctness Properties

*A property is a characteristic or behavior that should hold true across all valid executions of a system—essentially, a formal statement about what the system should do. Properties serve as the bridge between human-readable specifications and machine-verifiable correctness guarantees.*

### Property Reflection

After analyzing all acceptance criteria, several properties can be consolidated:

- **Data Persistence Properties (3.1-3.6)**: All assessment types follow the same save/load pattern. These can be unified into a single round-trip property that applies to any assessment type.
- **Report Display Properties (4.1-4.6)**: All data display requirements can be combined into one property that checks for completeness of displayed information.
- **Chatbot Context Properties (5.4-5.7)**: All context access requirements can be unified into a single property about complete data availability.
- **Progress Display Properties (6.1-6.3)**: All progress indicator requirements can be combined into one property about progress information completeness.
- **Score Calculation Properties (7.1, 7.3)**: Both GAD-7 and PHQ-9 follow the same calculation pattern (sum of responses).
- **Severity Classification Properties (7.2, 7.4)**: Both follow the same pattern of mapping scores to severity levels.

### Property 1: Session State Persistence

*For any* workflow session at any step with any accumulated assessment data, saving the session state and then loading it should return a session with the same session ID, same current step, and same assessment data.

**Validates: Requirements 1.6, 1.7**

### Property 2: Assessment Data Round-Trip

*For any* assessment type (GAD-7, PHQ-9, emotion, lifestyle) and any valid assessment data, saving the data to the data store and then loading it using the same session ID should return data equivalent to the original.

**Validates: Requirements 3.1, 3.2, 3.3, 3.4, 3.5, 3.6**

### Property 3: Workflow Step Advancement

*For any* workflow session at step N (where N < total steps), completing the current step and advancing should result in the session being at step N+1, and the completed step should be added to the list of completed steps.

**Validates: Requirements 1.6, 6.4**

### Property 4: Score Calculation Correctness

*For any* set of assessment responses (GAD-7 or PHQ-9), the calculated total score should equal the sum of all individual response values.

**Validates: Requirements 7.1, 7.3**

### Property 5: Severity Classification Correctness

*For any* assessment score, the determined severity level should match the defined classification ranges:
- GAD-7: 0-4 (minimal), 5-9 (mild), 10-14 (moderate), 15-21 (severe)
- PHQ-9: 0-4 (minimal), 5-9 (mild), 10-14 (moderate), 15-19 (moderately severe), 20-27 (severe)

**Validates: Requirements 7.2, 7.4**

### Property 6: Report Data Completeness

*For any* session with all assessments completed (GAD-7, PHQ-9, emotion, lifestyle), the generated analysis report should contain all of the following data elements: GAD-7 score, GAD-7 severity, PHQ-9 score, PHQ-9 severity, emotion results, and all eight lifestyle responses.

**Validates: Requirements 4.1, 4.2, 4.3, 4.4, 4.5, 4.6, 4.7**

### Property 7: Chatbot Context Completeness

*For any* session ID passed to the chatbot, the loaded context should include all completed assessment data: GAD-7 results (if completed), PHQ-9 results (if completed), emotion results (if completed), and lifestyle responses (if completed).

**Validates: Requirements 5.4, 5.5, 5.6, 5.7**

### Property 8: Progress Indicator Accuracy

*For any* active workflow session, the progress indicator should display: (1) current step number matching the actual current step, (2) total steps equal to 5, and (3) percentage calculated as (current_step / total_steps) * 100.

**Validates: Requirements 6.1, 6.2, 6.3**

### Property 9: Session Data Isolation

*For any* two different session IDs, assessment data saved under one session ID should not be retrievable using the other session ID.

**Validates: Requirements 3.5, 9.1**

### Property 10: Lifestyle Form Completeness

*For any* lifestyle questionnaire submission, all eight question responses (hobbies, eating habits, daily life, sleep schedule, meditation, exercise, feel good activities, happiness triggers) should be persisted and retrievable.

**Validates: Requirements 2.1, 2.2, 2.3, 2.4, 2.5, 2.6, 2.7, 2.8, 2.9**

## Error Handling

### Error Categories

1. **Camera Access Failures**
   - User denies camera permission
   - Camera hardware unavailable
   - Browser doesn't support camera API

2. **Data Persistence Failures**
   - Disk write errors
   - Permission issues
   - Invalid data format

3. **Session Management Failures**
   - Session expired
   - Invalid session ID
   - Session data corrupted

4. **Network/Integration Failures**
   - Chatbot service unavailable
   - Request timeout
   - Invalid response format

### Error Handling Strategies

#### Camera Access Errors

```python
try:
    # Emotion detection logic
    pass
except CameraAccessError as e:
    return {
        'error': True,
        'message': 'Unable to access camera. Please check permissions.',
        'actions': ['retry', 'skip'],
        'can_continue': True
    }
```

**User Experience**:
- Display friendly error message
- Offer "Retry" button to attempt camera access again
- Offer "Skip" button to continue workflow without emotion data
- Workflow can proceed with partial data

#### Data Persistence Errors

```python
try:
    save_session_data(session_id, data)
except DataStoreError as e:
    logger.error(f"Failed to save session {session_id}: {e}")
    return {
        'error': True,
        'message': 'Unable to save your data. Please try again.',
        'actions': ['retry'],
        'can_continue': False
    }
```

**User Experience**:
- Display error message with retry option
- Log error details for debugging
- Do not advance workflow until data is saved
- Preserve form data in browser for retry

#### Session Retrieval Errors

```python
def load_session_or_error(session_id: str) -> tuple:
    """Returns (data, error) tuple."""
    try:
        data = load_session_data(session_id)
        if data is None:
            return None, {
                'error': True,
                'message': 'Session not found. Please start a new assessment.',
                'redirect': '/complete-analysis/start'
            }
        return data, None
    except Exception as e:
        logger.error(f"Error loading session {session_id}: {e}")
        return None, {
            'error': True,
            'message': 'Unable to load your assessment data.',
            'actions': ['retry', 'start_new']
        }
```

**User Experience**:
- Clear error message explaining the issue
- Option to retry loading
- Option to start new assessment
- Redirect to home if session is invalid

#### Chatbot Integration Errors

```python
try:
    context = load_assessment_context(session_id)
    # Pass to chatbot
except Exception as e:
    logger.error(f"Failed to load context for chatbot: {e}")
    return {
        'error': True,
        'message': 'Unable to share your assessment with Jaya. You can still chat without context.',
        'actions': ['retry', 'continue_without_context']
    }
```

**User Experience**:
- Inform user of context loading failure
- Allow chatbot use without assessment context
- Offer retry option
- Graceful degradation

### Error Recovery Mechanisms

1. **Automatic Retry with Exponential Backoff**
   - For transient failures (network, temporary file locks)
   - Max 3 retry attempts
   - Delays: 1s, 2s, 4s

2. **Partial Data Acceptance**
   - Workflow can complete with some assessments skipped
   - Report clearly indicates missing data
   - Chatbot context includes only available data

3. **Session Recovery**
   - Session state saved after each step
   - User can resume from last completed step
   - Session expiry: 24 hours (configurable)

4. **Data Validation**
   - Validate data before persistence
   - Reject invalid data with clear error messages
   - Client-side validation to catch errors early

## Testing Strategy

### Dual Testing Approach

This feature requires both unit tests and property-based tests for comprehensive coverage:

- **Unit Tests**: Verify specific examples, edge cases, error conditions, and UI interactions
- **Property Tests**: Verify universal properties across all possible inputs using randomization

### Property-Based Testing

**Library**: `hypothesis` (Python)

**Configuration**: Minimum 100 iterations per property test

**Test Tagging**: Each property test must reference its design document property using the format:
```python
# Feature: complete-analysis-workflow, Property 1: Session State Persistence
```

### Property Test Examples

#### Property 1: Session State Persistence

```python
from hypothesis import given, strategies as st
import hypothesis

@given(
    step=st.sampled_from(['gad7', 'phq9', 'emotion', 'lifestyle']),
    gad7_score=st.integers(min_value=0, max_value=21),
    phq9_score=st.integers(min_value=0, max_value=27)
)
@hypothesis.settings(max_examples=100)
def test_session_state_persistence(step, gad7_score, phq9_score):
    """Feature: complete-analysis-workflow, Property 1: Session State Persistence"""
    # Create session with random data
    session_id = start_workflow()
    
    # Add random assessment data
    if step in ['phq9', 'emotion', 'lifestyle']:
        save_assessment_data(session_id, 'gad7', {'score': gad7_score})
    if step in ['emotion', 'lifestyle']:
        save_assessment_data(session_id, 'phq9', {'score': phq9_score})
    
    # Save and load
    original_state = get_workflow_state(session_id)
    loaded_state = get_workflow_state(session_id)
    
    # Verify equivalence
    assert loaded_state['session_id'] == original_state['session_id']
    assert loaded_state['current_step'] == original_state['current_step']
    assert loaded_state['assessments'] == original_state['assessments']
```

#### Property 2: Assessment Data Round-Trip

```python
@given(
    assessment_type=st.sampled_from(['gad7', 'phq9', 'emotion', 'lifestyle']),
    score=st.integers(min_value=0, max_value=27),
    text_response=st.text(min_size=1, max_size=500)
)
@hypothesis.settings(max_examples=100)
def test_assessment_data_round_trip(assessment_type, score, text_response):
    """Feature: complete-analysis-workflow, Property 2: Assessment Data Round-Trip"""
    session_id = start_workflow()
    
    # Create assessment data based on type
    if assessment_type in ['gad7', 'phq9']:
        data = {'score': score, 'severity': calculate_severity(assessment_type, score)}
    else:
        data = {'response': text_response}
    
    # Save and load
    save_assessment_data(session_id, assessment_type, data)
    loaded_data = get_assessment(session_id, assessment_type)
    
    # Verify equivalence
    assert loaded_data == data
```

#### Property 4: Score Calculation Correctness

```python
@given(
    responses=st.lists(
        st.integers(min_value=0, max_value=3),
        min_size=7,
        max_size=9
    )
)
@hypothesis.settings(max_examples=100)
def test_score_calculation_correctness(responses):
    """Feature: complete-analysis-workflow, Property 4: Score Calculation Correctness"""
    assessment_type = 'gad7' if len(responses) == 7 else 'phq9'
    
    calculated_score = calculate_assessment_score(assessment_type, responses)
    expected_score = sum(responses)
    
    assert calculated_score == expected_score
```

### Unit Test Coverage

#### Workflow Sequence Tests

```python
def test_workflow_starts_with_gad7():
    """Validates: Requirement 1.1"""
    session_id = start_workflow()
    state = get_workflow_state(session_id)
    assert state['current_step'] == 'gad7'

def test_workflow_sequence_gad7_to_phq9():
    """Validates: Requirement 1.2"""
    session_id = start_workflow()
    complete_step(session_id, 'gad7', {'score': 10})
    state = get_workflow_state(session_id)
    assert state['current_step'] == 'phq9'

def test_workflow_sequence_complete():
    """Validates: Requirements 1.1-1.5"""
    session_id = start_workflow()
    
    # Complete all steps
    complete_step(session_id, 'gad7', {'score': 10})
    assert get_workflow_state(session_id)['current_step'] == 'phq9'
    
    complete_step(session_id, 'phq9', {'score': 15})
    assert get_workflow_state(session_id)['current_step'] == 'emotion'
    
    complete_step(session_id, 'emotion', {'emotion': 'happy'})
    assert get_workflow_state(session_id)['current_step'] == 'lifestyle'
    
    complete_step(session_id, 'lifestyle', {'hobbies': 'reading'})
    assert get_workflow_state(session_id)['current_step'] == 'report'
```

#### Lifestyle Form Tests

```python
def test_lifestyle_form_has_all_fields():
    """Validates: Requirements 2.1-2.8"""
    # Render lifestyle form
    html = render_template('workflow_lifestyle.html')
    
    # Check for all 8 question fields
    assert 'hobbies' in html
    assert 'eating_habits' in html
    assert 'daily_life' in html
    assert 'sleep_schedule' in html
    assert 'meditation' in html
    assert 'exercise' in html
    assert 'feel_good_activities' in html
    assert 'happiness_triggers' in html
```

#### Error Handling Tests

```python
def test_camera_access_error_handling():
    """Validates: Requirement 8.1"""
    # Simulate camera access failure
    with mock.patch('emotion_detector.access_camera', side_effect=CameraAccessError):
        response = workflow_emotion()
        assert 'error' in response
        assert 'retry' in response['actions']
        assert 'skip' in response['actions']

def test_data_persistence_error_handling():
    """Validates: Requirement 8.2"""
    # Simulate write failure
    with mock.patch('data_store.save_session_data', return_value=False):
        response = submit_workflow_gad7({'score': 10})
        assert 'error' in response
        assert 'retry' in response['actions']

def test_session_retrieval_error_handling():
    """Validates: Requirement 8.3"""
    # Request report for non-existent session
    response = workflow_report('invalid-session-id')
    assert 'error' in response
    assert 'Session not found' in response['message']
```

#### Severity Classification Tests

```python
def test_gad7_severity_classification():
    """Validates: Requirement 7.2"""
    assert calculate_severity('gad7', 3) == 'minimal'
    assert calculate_severity('gad7', 7) == 'mild'
    assert calculate_severity('gad7', 12) == 'moderate'
    assert calculate_severity('gad7', 18) == 'severe'

def test_phq9_severity_classification():
    """Validates: Requirement 7.4"""
    assert calculate_severity('phq9', 3) == 'minimal'
    assert calculate_severity('phq9', 7) == 'mild'
    assert calculate_severity('phq9', 12) == 'moderate'
    assert calculate_severity('phq9', 17) == 'moderately_severe'
    assert calculate_severity('phq9', 24) == 'severe'
```

#### UI Component Tests

```python
def test_report_displays_concern_with_jaya_button():
    """Validates: Requirement 5.1"""
    session_id = create_complete_session()
    html = render_template('workflow_report.html', session_id=session_id)
    assert 'Concern with Jaya' in html
    assert f'/chatbot/with-context/{session_id}' in html
```

### Integration Tests

```python
def test_complete_workflow_integration():
    """End-to-end test of complete workflow"""
    # Start workflow
    session_id = start_workflow()
    
    # Complete GAD-7
    gad7_data = {'score': 12, 'severity': 'moderate'}
    save_assessment_data(session_id, 'gad7', gad7_data)
    advance_step(session_id)
    
    # Complete PHQ-9
    phq9_data = {'score': 15, 'severity': 'moderately_severe'}
    save_assessment_data(session_id, 'phq9', phq9_data)
    advance_step(session_id)
    
    # Complete Emotion
    emotion_data = {'detected_emotion': 'sad', 'confidence': 0.85}
    save_assessment_data(session_id, 'emotion', emotion_data)
    advance_step(session_id)
    
    # Complete Lifestyle
    lifestyle_data = {
        'hobbies': 'Reading',
        'eating_habits': 'Regular meals',
        'daily_life': 'Busy',
        'sleep_schedule': '7 hours',
        'meditation': 'Yes',
        'exercise': 'Daily',
        'feel_good_activities': 'Music',
        'happiness_triggers': 'Family time'
    }
    save_assessment_data(session_id, 'lifestyle', lifestyle_data)
    advance_step(session_id)
    
    # Verify report generation
    report_data = load_session_data(session_id)
    assert report_data['assessments']['gad7'] == gad7_data
    assert report_data['assessments']['phq9'] == phq9_data
    assert report_data['assessments']['emotion'] == emotion_data
    assert report_data['assessments']['lifestyle'] == lifestyle_data
    
    # Verify chatbot context
    context = load_assessment_context(session_id)
    assert 'GAD-7' in context
    assert 'PHQ-9' in context
    assert 'Emotion' in context
    assert 'Lifestyle' in context
```

### Test Organization

```
tests/
├── unit/
│   ├── test_workflow_orchestrator.py
│   ├── test_data_store.py
│   ├── test_score_calculation.py
│   └── test_severity_classification.py
├── property/
│   ├── test_session_persistence_property.py
│   ├── test_data_round_trip_property.py
│   ├── test_score_calculation_property.py
│   └── test_severity_classification_property.py
├── integration/
│   ├── test_complete_workflow.py
│   └── test_chatbot_integration.py
└── ui/
    ├── test_templates.py
    └── test_error_pages.py
```

### Test Execution

```bash
# Run all tests
pytest tests/

# Run only property tests
pytest tests/property/

# Run with coverage
pytest --cov=. --cov-report=html tests/

# Run specific property test with verbose output
pytest tests/property/test_session_persistence_property.py -v
```

### Continuous Integration

- All tests must pass before merging
- Property tests run with 100 iterations in CI
- Coverage target: 85% for new code
- Integration tests run on every pull request
